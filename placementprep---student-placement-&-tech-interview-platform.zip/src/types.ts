export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export interface TestCase {
  id: string;
  input: string;
  expectedOutput: string;
  isPublic: boolean;
}

export interface Problem {
  id: string;
  title: string;
  difficulty: Difficulty;
  category: string;
  acceptanceRate: number;
  companies: string[];
  description: string;
  examples: {
    input: string;
    output: string;
    explanation?: string;
  }[];
  constraints: string[];
  starterCode: {
    javascript: string;
    python: string;
    cpp: string;
    java: string;
  };
  hints: string[];
  solutionExplanation?: string;
}

export interface CodeSubmission {
  id: string;
  problemId: string;
  problemTitle: string;
  code: string;
  language: string;
  status: 'Accepted' | 'Wrong Answer' | 'Time Limit Exceeded' | 'Runtime Error';
  passedCount: number;
  totalCount: number;
  runtimeMs: number;
  memoryMb: number;
  timestamp: string;
}

export interface AIReviewResult {
  verdict: string;
  overallScore: number;
  timeComplexity: string;
  spaceComplexity: string;
  strengths: string[];
  weaknesses: string[];
  edgeCasesMissed?: string[];
  codeSmells?: string[];
  optimizedCodeSnippet?: string;
  keyAdvice: string;
}

export interface LeaderboardUser {
  rank: number;
  id: string;
  name: string;
  college: string;
  solvedCount?: number;
  problemsSolved?: number;
  xp: number;
  streakDays: number;
  badge: string;
  avatar: string;
  isCurrentUser?: boolean;
}

export interface CompanyHiringCriteria {
  id: string;
  name: string;
  logo: string;
  category: 'FAANG/MAANG' | 'Tier-1 Product' | 'Fintech' | 'High-Growth Startup';
  minCgpa: number;
  avgCtc: string; // e.g. "45 - 55 LPA ($140k+)"
  dsaDifficulty: 'Medium' | 'Medium-Hard' | 'Hard';
  rounds: {
    roundName: string;
    focus: string;
    prepStrategy: string;
  }[];
  preferredTechStack: string[];
  eligibilityCriteria: string[];
  insiderTips: string;
  targetTopics: string[];
}

export interface JobDeadline {
  id: string;
  company: string;
  role: string;
  type: 'Internship' | 'Full-Time' | 'Off-Campus Drive';
  location: string;
  deadlineDate: string; // YYYY-MM-DD
  daysLeft: number;
  ctcOffer: string;
  eligibility: string;
  applyLink: string;
  isBookmarked?: boolean;
  batch: string;
  tags: string[];
}

export interface RoadmapTopic {
  id: string;
  title: string;
  description: string;
  status: 'completed' | 'in-progress' | 'not-started';
  estimatedHours: number;
  resourceLinks: { label: string; url: string; isVideo?: boolean }[];
  problemsToSolve: string[]; // Problem IDs or Titles
}

export interface RoadmapPhase {
  phaseNumber: number;
  title: string;
  level: 'Absolute Beginner (Step 0)' | 'Core Foundations' | 'Interview Mastery' | 'Advanced Scale & Mock';
  weeks: string;
  summary: string;
  topics: RoadmapTopic[];
}

export interface StudySheet {
  id: string;
  category: 'Operating Systems' | 'DBMS & SQL' | 'Computer Networks' | 'OOPs & Clean Code' | 'System Design';
  title: string;
  readTime: string;
  keyTakeaways: string[];
  contentMarkdown: string;
  commonInterviewQuestions: {
    question: string;
    answerSummary: string;
  }[];
}

export interface ForumReply {
  id: string;
  author: string;
  avatar?: string;
  content: string;
  createdAt: string;
  isAccepted?: boolean;
  isAiAnswer?: boolean;
  upvotes: number;
}

export interface ForumPost {
  id: string;
  title: string;
  content?: string;
  body?: string;
  author: string;
  authorCollege?: string;
  avatar?: string;
  category?: string;
  tags: string[];
  createdAt: string;
  upvotes: number;
  replies: ForumReply[];
  hasAcceptedAnswer?: boolean;
  hasAiAnswer?: boolean;
  views?: number;
}

export interface CollaborativeSpace {
  id: string;
  projectTitle: string;
  description: string;
  techStack: string;
  membersCount: number;
  activeCodeSnippet: string;
  reviewComments: {
    id: string;
    author: string;
    comment: string;
    timestamp: string;
  }[];
}

export interface ResumeData {
  fullName: string;
  email: string;
  phone: string;
  linkedin: string;
  github: string;
  portfolio: string;
  targetRole: string;
  education: {
    id: string;
    institution: string;
    degree: string;
    fieldOfStudy: string;
    startYear: string;
    endYear: string;
    cgpa: string;
  }[];
  experience: {
    id: string;
    company: string;
    role: string;
    location: string;
    startDate: string;
    endDate: string;
    isCurrent: boolean;
    bulletPoints: string[];
  }[];
  projects: {
    id: string;
    title: string;
    techStack: string;
    liveUrl?: string;
    githubUrl?: string;
    bulletPoints: string[];
  }[];
  skills: {
    languages: string;
    frameworks: string;
    developerTools: string;
    coreConcepts: string;
  };
  achievements: string[];
}

export interface PortfolioBlueprint {
  id: string;
  title: string;
  category: 'Full Stack & Distributed' | 'Backend Systems & Infra' | 'DevOps & Tooling' | 'AI & ML Systems';
  difficulty: 'Intermediate' | 'Advanced';
  tagline: string;
  whyRecruitersHire: string;
  architecturePoints: string[];
  techStack: string[];
  keyFeatures: string[];
  atsResumeBullet: string;
  githubTemplateIdea: string;
}

export interface CollaborativeProjectTask {
  id: string;
  title: string;
  assignee: string;
  priority: 'High' | 'Medium' | 'Low';
  status: 'todo' | 'in-progress' | 'review' | 'done';
}

export interface PeerReviewSnippet {
  id: string;
  author: string;
  title: string;
  language: string;
  code: string;
  comments: {
    id: string;
    author: string;
    line: number;
    comment: string;
    timestamp: string;
  }[];
}
