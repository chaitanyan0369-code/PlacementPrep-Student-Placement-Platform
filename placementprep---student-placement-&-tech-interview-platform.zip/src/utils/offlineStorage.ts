// Utility for managing offline study materials and local state persistence

export const OFFLINE_KEYS = {
  PROBLEMS: 'placementprep_problems',
  PROGRESS: 'placementprep_progress',
  STUDY_SHEETS: 'placementprep_study_sheets',
  RESUME: 'placementprep_resume',
  DEADLINES: 'placementprep_deadlines',
  THEME: 'placementprep_theme',
  SAVED_CODE: 'placementprep_saved_code_',
};

export function saveOfflineData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.warn('LocalStorage quota or write error:', err);
  }
}

export function getOfflineData<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    return JSON.parse(item) as T;
  } catch (err) {
    console.warn('LocalStorage read error for key:', key, err);
    return fallback;
  }
}

export const loadOfflineData = getOfflineData;
