import { Problem, CompanyHiringCriteria, JobDeadline, RoadmapPhase, StudySheet, LeaderboardUser, PortfolioBlueprint, ForumPost, PeerReviewSnippet } from '../types';

export const INITIAL_PROBLEMS: Problem[] = [
  {
    id: 'two-sum',
    title: 'Two Sum',
    difficulty: 'Easy',
    category: 'Arrays & Hashing',
    acceptanceRate: 52.4,
    companies: ['Google', 'Amazon', 'Microsoft', 'Meta', 'Apple'],
    description: `Given an array of integers \`nums\` and an integer \`target\`, return indices of the two numbers such that they add up to \`target\`.

You may assume that each input would have exactly one solution, and you may not use the same element twice. You can return the answer in any order.`,
    examples: [
      {
        input: 'nums = [2,7,11,15], target = 9',
        output: '[0,1]',
        explanation: 'Because nums[0] + nums[1] == 9, we return [0, 1].',
      },
      {
        input: 'nums = [3,2,4], target = 6',
        output: '[1,2]',
      },
    ],
    constraints: [
      '2 <= nums.length <= 10^4',
      '-10^9 <= nums[i] <= 10^9',
      '-10^9 <= target <= 10^9',
      'Only one valid answer exists.',
    ],
    starterCode: {
      javascript: `function twoSum(nums, target) {
  // Your optimal O(N) solution here
  const map = new Map();
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (map.has(complement)) {
      return [map.get(complement), i];
    }
    map.set(nums[i], i);
  }
  return [];
}`,
      python: `def twoSum(nums: list[int], target: int) -> list[int]:
    lookup = {}
    for i, num in enumerate(nums):
        diff = target - num
        if diff in lookup:
            return [lookup[diff], i]
        lookup[num] = i
    return []`,
      cpp: `#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        unordered_map<int, int> seen;
        for (int i = 0; i < nums.size(); i++) {
            int comp = target - nums[i];
            if (seen.count(comp)) return {seen[comp], i};
            seen[nums[i]] = i;
        }
        return {};
    }
};`,
      java: `import java.util.HashMap;

class Solution {
    public int[] twoSum(int[] nums, int target) {
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement)) {
                return new int[] { map.get(complement), i };
            }
            map.put(nums[i], i);
        }
        return new int[0];
    }
}`,
    },
    hints: [
      'A brute-force search takes O(N^2) time. Can you do it in a single pass?',
      'Use a Hash Map to store numbers you have already visited and their indices.',
    ],
    solutionExplanation: 'By using a hash map, we achieve O(N) time complexity and O(N) space complexity by looking up the required complement (target - current_val) in O(1) average time.',
  },
  {
    id: 'lru-cache',
    title: 'LRU Cache (Least Recently Used)',
    difficulty: 'Medium',
    category: 'Design & Linked List',
    acceptanceRate: 41.8,
    companies: ['Amazon', 'Google', 'Microsoft', 'Uber', 'Bloomberg'],
    description: `Design a data structure that follows the constraints of a Least Recently Used (LRU) cache.

Implement the \`LRUCache\` class:
- \`LRUCache(int capacity)\` Initialize the LRU cache with positive size capacity.
- \`int get(int key)\` Return the value of the key if the key exists, otherwise return -1.
- \`void put(int key, int value)\` Update the value of the key if the key exists. Otherwise, add the key-value pair. If keys exceed capacity, evict least recently used key.

Both \`get\` and \`put\` must each run in O(1) average time complexity.`,
    examples: [
      {
        input: '["LRUCache", "put", "put", "get", "put", "get", "put", "get", "get", "get"]\n[[2], [1, 1], [2, 2], [1], [3, 3], [2], [4, 4], [1], [3], [4]]',
        output: '[null, null, null, 1, null, -1, null, -1, 3, 4]',
        explanation: 'Cache operations evict key 2 when capacity is exceeded, key 1 remains updated.',
      },
    ],
    constraints: [
      '1 <= capacity <= 3000',
      '0 <= key <= 10^4',
      '0 <= value <= 10^5',
      'At most 2 * 10^5 calls will be made to get and put.',
    ],
    starterCode: {
      javascript: `class LRUCache {
  /**
   * @param {number} capacity
   */
  constructor(capacity) {
    this.capacity = capacity;
    this.map = new Map(); // In JS, Map preserves insertion order!
  }

  /** 
   * @param {number} key
   * @return {number}
   */
  get(key) {
    if (!this.map.has(key)) return -1;
    const val = this.map.get(key);
    this.map.delete(key);
    this.map.set(key, val); // Move to recent
    return val;
  }

  /** 
   * @param {number} key 
   * @param {number} value
   * @return {void}
   */
  put(key, value) {
    if (this.map.has(key)) {
      this.map.delete(key);
    } else if (this.map.size >= this.capacity) {
      // Delete oldest entry
      const oldestKey = this.map.keys().next().value;
      this.map.delete(oldestKey);
    }
    this.map.set(key, value);
  }
}`,
      python: `class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = {} # In Python 3.7+, dict preserves insertion order or use OrderedDict

    def get(self, key: int) -> int:
        if key not in self.cache:
            return -1
        val = self.cache.pop(key)
        self.cache[key] = val
        return val

    def put(self, key: int, value: int) -> None:
        if key in self.cache:
            self.cache.pop(key)
        elif len(self.cache) >= self.capacity:
            oldest = next(iter(self.cache))
            del self.cache[oldest]
        self.cache[key] = value`,
      cpp: `#include <list>
#include <unordered_map>
using namespace std;

class LRUCache {
    int cap;
    list<pair<int, int>> dll;
    unordered_map<int, list<pair<int, int>>::iterator> map;
public:
    LRUCache(int capacity) : cap(capacity) {}
    
    int get(int key) {
        if (!map.count(key)) return -1;
        dll.splice(dll.begin(), dll, map[key]);
        return map[key]->second;
    }
    
    void put(int key, int value) {
        if (map.count(key)) {
            dll.splice(dll.begin(), dll, map[key]);
            map[key]->second = value;
            return;
        }
        if (dll.size() == cap) {
            int oldKey = dll.back().first;
            dll.pop_back();
            map.erase(oldKey);
        }
        dll.emplace_front(key, value);
        map[key] = dll.begin();
    }
};`,
      java: `import java.util.LinkedHashMap;
import java.util.Map;

class LRUCache extends LinkedHashMap<Integer, Integer> {
    private int capacity;
    
    public LRUCache(int capacity) {
        super(capacity, 0.75f, true);
        this.capacity = capacity;
    }
    
    public int get(int key) {
        return super.getOrDefault(key, -1);
    }
    
    public void put(int key, int value) {
        super.put(key, value);
    }
    
    @Override
    protected boolean removeEldestEntry(Map.Entry<Integer, Integer> eldest) {
        return size() > capacity;
    }
}`,
    },
    hints: [
      'Combine a Doubly Linked List with a Hash Map to achieve O(1) insertion, deletion, and search.',
      'The Doubly Linked List maintains the order of access, while the Hash Map enables instant pointer lookups.',
    ],
  },
  {
    id: 'trapping-rain-water',
    title: 'Trapping Rain Water',
    difficulty: 'Hard',
    category: 'Two Pointers & Monotonic Stack',
    acceptanceRate: 60.1,
    companies: ['Google', 'Amazon', 'Goldman Sachs', 'Uber', 'Microsoft'],
    description: `Given \`n\` non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.`,
    examples: [
      {
        input: 'height = [0,1,0,2,1,0,1,3,2,1,2,1]',
        output: '6',
        explanation: 'The above elevation map (black section) traps 6 units of rain water (blue section).',
      },
      {
        input: 'height = [4,2,0,3,2,5]',
        output: '9',
      },
    ],
    constraints: [
      'n == height.length',
      '1 <= n <= 2 * 10^4',
      '0 <= height[i] <= 10^5',
    ],
    starterCode: {
      javascript: `function trap(height) {
  let left = 0, right = height.length - 1;
  let leftMax = 0, rightMax = 0;
  let water = 0;

  while (left < right) {
    if (height[left] < height[right]) {
      if (height[left] >= leftMax) {
        leftMax = height[left];
      } else {
        water += leftMax - height[left];
      }
      left++;
    } else {
      if (height[right] >= rightMax) {
        rightMax = height[right];
      } else {
        water += rightMax - height[right];
      }
      right--;
    }
  }
  return water;
}`,
      python: `def trap(height: list[int]) -> int:
    left, right = 0, len(height) - 1
    left_max, right_max = 0, 0
    water = 0
    while left < right:
        if height[left] < height[right]:
            if height[left] >= left_max:
                left_max = height[left]
            else:
                water += left_max - height[left]
            left += 1
        else:
            if height[right] >= right_max:
                right_max = height[right]
            else:
                water += right_max - height[right]
            right -= 1
    return water`,
      cpp: `#include <vector>
using namespace std;

class Solution {
public:
    int trap(vector<int>& height) {
        int l = 0, r = height.size() - 1;
        int lMax = 0, rMax = 0, trapped = 0;
        while (l < r) {
            if (height[l] < height[r]) {
                if (height[l] >= lMax) lMax = height[l];
                else trapped += lMax - height[l];
                l++;
            } else {
                if (height[r] >= rMax) rMax = height[r];
                else trapped += rMax - height[r];
                r--;
            }
        }
        return trapped;
    }
};`,
      java: `class Solution {
    public int trap(int[] height) {
        int left = 0, right = height.length - 1;
        int leftMax = 0, rightMax = 0;
        int totalWater = 0;
        while (left < right) {
            if (height[left] < height[right]) {
                if (height[left] >= leftMax) leftMax = height[left];
                else totalWater += leftMax - height[left];
                left++;
            } else {
                if (height[right] >= rightMax) rightMax = height[right];
                else totalWater += rightMax - height[right];
                right--;
            }
        }
        return totalWater;
    }
}`,
    },
    hints: [
      'Water trapped at any index depends on the minimum of max height to its left and max height to its right.',
      'Instead of precomputing arrays for leftMax and rightMax, use a two-pointer technique for O(1) extra space.',
    ],
  },
  {
    id: 'course-schedule',
    title: 'Course Schedule (Topological Sort / Cycle Detection)',
    difficulty: 'Medium',
    category: 'Graphs & BFS/DFS',
    acceptanceRate: 46.5,
    companies: ['Google', 'Meta', 'Amazon', 'Microsoft', 'Uber'],
    description: `There are a total of \`numCourses\` courses you have to take, labeled from \`0\` to \`numCourses - 1\`. You are given an array \`prerequisites\` where \`prerequisites[i] = [a_i, b_i]\` indicates that you must take course \`b_i\` first if you want to take course \`a_i\`.

Return \`true\` if you can finish all courses. Otherwise, return \`false\`.`,
    examples: [
      {
        input: 'numCourses = 2, prerequisites = [[1,0]]',
        output: 'true',
        explanation: 'There are a total of 2 courses to take. To take course 1 you should have finished course 0. So it is possible.',
      },
      {
        input: 'numCourses = 2, prerequisites = [[1,0],[0,1]]',
        output: 'false',
        explanation: 'There are 2 courses to take. Cycle detected between 0 and 1.',
      },
    ],
    constraints: [
      '1 <= numCourses <= 2000',
      '0 <= prerequisites.length <= 5000',
      'prerequisites[i].length == 2',
      '0 <= a_i, b_i < numCourses',
    ],
    starterCode: {
      javascript: `function canFinish(numCourses, prerequisites) {
  const inDegree = new Array(numCourses).fill(0);
  const adj = Array.from({ length: numCourses }, () => []);

  for (const [course, pre] of prerequisites) {
    adj[pre].push(course);
    inDegree[course]++;
  }

  const queue = [];
  for (let i = 0; i < numCourses; i++) {
    if (inDegree[i] === 0) queue.push(i);
  }

  let visited = 0;
  while (queue.length > 0) {
    const node = queue.shift();
    visited++;
    for (const neighbor of adj[node]) {
      inDegree[neighbor]--;
      if (inDegree[neighbor] === 0) {
        queue.push(neighbor);
      }
    }
  }

  return visited === numCourses;
}`,
      python: `from collections import deque

def canFinish(numCourses: int, prerequisites: list[list[int]]) -> bool:
    in_degree = [0] * numCourses
    adj = [[] for _ in range(numCourses)]
    for dest, src in prerequisites:
        adj[src].append(dest)
        in_degree[dest] += 1
    
    queue = deque([i for i in range(numCourses) if in_degree[i] == 0])
    count = 0
    while queue:
        node = queue.popleft()
        count += 1
        for nxt in adj[node]:
            in_degree[nxt] -= 1
            if in_degree[nxt] == 0:
                queue.append(nxt)
    return count == numCourses`,
      cpp: `#include <vector>
#include <queue>
using namespace std;

class Solution {
public:
    bool canFinish(int numCourses, vector<vector<int>>& prerequisites) {
        vector<int> inDegree(numCourses, 0);
        vector<vector<int>> adj(numCourses);
        for (auto& p : prerequisites) {
            adj[p[1]].push_back(p[0]);
            inDegree[p[0]]++;
        }
        queue<int> q;
        for (int i = 0; i < numCourses; i++) {
            if (inDegree[i] == 0) q.push(i);
        }
        int processed = 0;
        while (!q.empty()) {
            int cur = q.front(); q.pop();
            processed++;
            for (int neighbor : adj[cur]) {
                if (--inDegree[neighbor] == 0) q.push(neighbor);
            }
        }
        return processed == numCourses;
    }
};`,
      java: `import java.util.*;

class Solution {
    public boolean canFinish(int numCourses, int[][] prerequisites) {
        int[] inDegree = new int[numCourses];
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i < numCourses; i++) adj.add(new ArrayList<>());
        
        for (int[] p : prerequisites) {
            adj.get(p[1]).add(p[0]);
            inDegree[p[0]]++;
        }
        
        Queue<Integer> queue = new LinkedList<>();
        for (int i = 0; i < numCourses; i++) {
            if (inDegree[i] == 0) queue.offer(i);
        }
        
        int count = 0;
        while (!queue.isEmpty()) {
            int node = queue.poll();
            count++;
            for (int next : adj.get(node)) {
                if (--inDegree[next] == 0) queue.offer(next);
            }
        }
        return count == numCourses;
    }
}`,
    },
    hints: [
      'This is equivalent to finding if there exists a directed cycle in a directed graph.',
      "Apply Kahn's Algorithm (BFS topological sort) using node in-degrees.",
    ],
  },
  {
    id: 'merge-intervals',
    title: 'Merge Intervals',
    difficulty: 'Medium',
    category: 'Intervals & Sorting',
    acceptanceRate: 47.9,
    companies: ['Google', 'Microsoft', 'Amazon', 'Meta', 'Salesforce'],
    description: `Given an array of \`intervals\` where \`intervals[i] = [start_i, end_i]\`, merge all overlapping intervals, and return an array of the non-overlapping intervals that cover all the intervals in the input.`,
    examples: [
      {
        input: 'intervals = [[1,3],[2,6],[8,10],[15,18]]',
        output: '[[1,6],[8,10],[15,18]]',
        explanation: 'Since intervals [1,3] and [2,6] overlap, merge them into [1,6].',
      },
    ],
    constraints: ['1 <= intervals.length <= 10^4', 'intervals[i].length == 2', '0 <= start_i <= end_i <= 10^4'],
    starterCode: {
      javascript: `function merge(intervals) {
  if (!intervals.length) return [];
  intervals.sort((a, b) => a[0] - b[0]);
  const result = [intervals[0]];
  for (let i = 1; i < intervals.length; i++) {
    const current = intervals[i];
    const prev = result[result.length - 1];
    if (current[0] <= prev[1]) {
      prev[1] = Math.max(prev[1], current[1]);
    } else {
      result.push(current);
    }
  }
  return result;
}`,
      python: `def merge(intervals: list[list[int]]) -> list[list[int]]:
    if not intervals:
        return []
    intervals.sort(key=lambda x: x[0])
    merged = [intervals[0]]
    for cur in intervals[1:]:
        if cur[0] <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], cur[1])
        else:
            merged.append(cur)
    return merged`,
      cpp: `#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    vector<vector<int>> merge(vector<vector<int>>& intervals) {
        if (intervals.empty()) return {};
        sort(intervals.begin(), intervals.end());
        vector<vector<int>> res = {intervals[0]};
        for (int i = 1; i < intervals.size(); i++) {
            if (intervals[i][0] <= res.back()[1]) {
                res.back()[1] = max(res.back()[1], intervals[i][1]);
            } else {
                res.push_back(intervals[i]);
            }
        }
        return res;
    }
};`,
      java: `import java.util.*;

class Solution {
    public int[][] merge(int[][] intervals) {
        if (intervals.length <= 1) return intervals;
        Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));
        List<int[]> result = new ArrayList<>();
        int[] current = intervals[0];
        result.add(current);
        for (int[] interval : intervals) {
            if (interval[0] <= current[1]) {
                current[1] = Math.max(current[1], interval[1]);
            } else {
                current = interval;
                result.add(current);
            }
        }
        return result.toArray(new int[result.size()][]);
    }
}`,
    },
    hints: [
      'If intervals are sorted by start time, overlapping intervals will always be adjacent.',
    ],
  },
];

export const ROADMAP_PHASES: RoadmapPhase[] = [
  {
    phaseNumber: 0,
    title: 'Beginner Foundations & Language Mastery',
    level: 'Absolute Beginner (Step 0)',
    weeks: 'Weeks 1 - 3',
    summary: 'Master one primary programming language (C++, Java, or Python), understand memory allocations, references, and basic algorithmic complexity (Big-O).',
    topics: [
      {
        id: 'lang-syntax',
        title: 'Choose Language & Core Syntax',
        description: 'Pointers/References, memory layout, functions, scope, and Standard Template Library (STL/Collections).',
        status: 'completed',
        estimatedHours: 15,
        resourceLinks: [
          { label: 'C++ STL Masterclass or Java Collections Cheatsheet', url: 'https://en.cppreference.com' },
          { label: 'CS50 Lecture on Memory & Pointers', url: 'https://cs50.harvard.edu', isVideo: true },
        ],
        problemsToSolve: ['Two Sum', 'Reverse String', 'Palindrome Number'],
      },
      {
        id: 'time-space-complexity',
        title: 'Big-O Asymptotic Analysis',
        description: 'Worst, Average, and Best case. Understanding recursive call stack memory limits.',
        status: 'completed',
        estimatedHours: 8,
        resourceLinks: [
          { label: 'Big-O Cheat Sheet Visualization', url: 'https://www.bigocheatsheet.com' },
        ],
        problemsToSolve: ['Binary Search', 'Linear Search Comparisons'],
      },
    ],
  },
  {
    phaseNumber: 1,
    title: 'Linear Data Structures & Classic Patterns',
    level: 'Core Foundations',
    weeks: 'Weeks 4 - 8',
    summary: 'Conquer Arrays, Strings, Two Pointers, Sliding Window, Fast/Slow Pointers, Stacks, and Hash Maps.',
    topics: [
      {
        id: 'two-pointers-sliding-window',
        title: 'Two Pointers & Dynamic Sliding Window',
        description: 'Fixed vs dynamic window, palindromes, 3Sum, container with most water.',
        status: 'in-progress',
        estimatedHours: 20,
        resourceLinks: [
          { label: 'NeetCode Two Pointer Deep Dive', url: 'https://neetcode.io', isVideo: true },
        ],
        problemsToSolve: ['Two Sum', 'Trapping Rain Water', 'Longest Substring Without Repeating Characters'],
      },
      {
        id: 'linked-list-stacks',
        title: 'Linked Lists & Monotonic Stacks',
        description: 'Reversal, Floyd cycle detection, Next Greater Element, LRU Cache implementation.',
        status: 'not-started',
        estimatedHours: 18,
        resourceLinks: [
          { label: 'Striver SDE Sheet Linked List Mastery', url: 'https://takeuforward.org' },
        ],
        problemsToSolve: ['LRU Cache (Least Recently Used)', 'Reverse Linked List', 'Daily Temperatures'],
      },
    ],
  },
  {
    phaseNumber: 2,
    title: 'Non-Linear Structures & Algorithmic Paradigms',
    level: 'Interview Mastery',
    weeks: 'Weeks 9 - 14',
    summary: 'Trees (BST, traversals, LCA), Graphs (BFS, DFS, Dijkstra, Topological Sort), and Dynamic Programming.',
    topics: [
      {
        id: 'trees-graphs',
        title: 'Binary Trees, BST & Graph Traversal',
        description: 'Inorder/Preorder/Postorder, BFS level order, cycle detection with Kahn’s algo.',
        status: 'not-started',
        estimatedHours: 28,
        resourceLinks: [
          { label: 'Graph Theory Algorithms Course', url: 'https://visualgo.net', isVideo: true },
        ],
        problemsToSolve: ['Course Schedule (Topological Sort / Cycle Detection)', 'Lowest Common Ancestor', 'Word Ladder'],
      },
      {
        id: 'dynamic-programming',
        title: 'Dynamic Programming Patterns',
        description: 'Memoization vs Tabulation, 0/1 Knapsack, Longest Common Subsequence, Grid paths.',
        status: 'not-started',
        estimatedHours: 25,
        resourceLinks: [
          { label: 'Errichto Dynamic Programming Guide', url: 'https://youtube.com', isVideo: true },
        ],
        problemsToSolve: ['Coin Change', 'Longest Increasing Subsequence', 'Edit Distance'],
      },
    ],
  },
  {
    phaseNumber: 3,
    title: 'Placement Readiness & Company Targeted Sprints',
    level: 'Advanced Scale & Mock',
    weeks: 'Weeks 15 - 18',
    summary: 'Core CS Subjects (OS, DBMS, Computer Networks), Low Level Design (OOPs & SOLID), High Level System Design, and Live Mock Interviews.',
    topics: [
      {
        id: 'core-cs-fundamentals',
        title: 'Operating Systems & DBMS Interviews',
        description: 'Processes vs Threads, CPU scheduling, Virtual memory, SQL queries, Indexing, ACID, Normalization.',
        status: 'not-started',
        estimatedHours: 20,
        resourceLinks: [
          { label: 'PlacementPrep Offline Notes Library', url: '#study-sheets' },
        ],
        problemsToSolve: ['Top 50 OS/DBMS Interview Questions'],
      },
      {
        id: 'mock-sprints',
        title: 'Timed Mock Interviews & Resume Tuning',
        description: 'Conducting STAR method behavioral simulations and live timed coding under pressure.',
        status: 'not-started',
        estimatedHours: 15,
        resourceLinks: [
          { label: 'PlacementPrep AI Mock Interviewer', url: '#mock-interview' },
        ],
        problemsToSolve: ['Google / Amazon SDE Mock Set'],
      },
    ],
  },
];

export const COMPANY_HIRING_DATA: CompanyHiringCriteria[] = [
  {
    id: 'google',
    name: 'Google',
    logo: 'https://www.google.com/favicon.ico',
    category: 'FAANG/MAANG',
    minCgpa: 7.0,
    avgCtc: '45 - 60 LPA ($150,000+)',
    dsaDifficulty: 'Hard',
    rounds: [
      { roundName: 'Online Assessment (OA)', focus: '2-3 Hard DSA Problems (Graphs, DP, Trees)', prepStrategy: 'Focus on novel edge cases and write modular clean functions.' },
      { roundName: 'Technical Round 1 & 2', focus: 'Data Structures, Algorithmic trade-offs, Graph modeling', prepStrategy: 'Think out loud. Always discuss time/space before writing a single line of code.' },
      { roundName: 'Googleyness & Leadership', focus: 'Behavioral scenarios, handling ambiguous problems, intellectual humility', prepStrategy: 'Use STAR format. Emphasize teamwork, curiosity, and ethical engineering.' },
    ],
    preferredTechStack: ['C++', 'Java', 'Python', 'Go', 'Distributed Systems'],
    eligibilityCriteria: [
      'B.Tech / B.E / M.Tech in CS or related quantitative discipline',
      'No active backlogs at time of joining',
      'Strong algorithmic problem solving & mathematical intuition',
    ],
    insiderTips: 'Google cares deeply about write-once, clean, production-grade syntax on Google Docs / Chromebook editors with no autocomplete. Practice coding without an IDE.',
    targetTopics: ['Hard Dynamic Programming', 'Segment Trees & Fenwick', 'Shortest Paths & Flow', 'Union-Find'],
  },
  {
    id: 'microsoft',
    name: 'Microsoft',
    logo: 'https://www.microsoft.com/favicon.ico',
    category: 'FAANG/MAANG',
    minCgpa: 7.5,
    avgCtc: '42 - 50 LPA ($130,000+)',
    dsaDifficulty: 'Medium-Hard',
    rounds: [
      { roundName: 'Online Test (Codility)', focus: '3 DSA questions (Strings, Arrays, Greedy)', prepStrategy: 'Ensure 100% test case pass rate with fast edge case checks.' },
      { roundName: 'Technical Round 1', focus: 'Trees, Linked Lists, Matrix traversal', prepStrategy: 'Clean pointer manipulation without memory leaks.' },
      { roundName: 'Technical Round 2 + CS Core', focus: 'OS (Threads, Deadlocks) + System Design basics', prepStrategy: 'Revise virtual memory, paging, and SQL vs NoSQL trade-offs.' },
      { roundName: 'AA (As Appropriate) / Director Round', focus: 'Cultural fit, projects deep dive, resilience', prepStrategy: 'Know every line on your resume. Be ready to explain your toughest bug.' },
    ],
    preferredTechStack: ['C#', 'C++', 'Java', 'Azure', 'TypeScript'],
    eligibilityCriteria: ['Min 7.0 or 7.5 CGPA depending on campus tier', 'No active arrears'],
    insiderTips: 'Microsoft loves checking if you write defensive code with null pointer checks and boundary condition validations.',
    targetTopics: ['Binary Trees & BST', 'String Parsing', 'Operating Systems', 'OOPs & Design Patterns'],
  },
  {
    id: 'amazon',
    name: 'Amazon',
    logo: 'https://www.amazon.com/favicon.ico',
    category: 'FAANG/MAANG',
    minCgpa: 6.5,
    avgCtc: '40 - 48 LPA ($140,000+)',
    dsaDifficulty: 'Medium-Hard',
    rounds: [
      { roundName: 'Online Assessment (Hackerrank)', focus: '2 DSA problems + Work Style Assessment (LP simulation)', prepStrategy: 'Take the behavioral LP section very seriously; it weighs equally with coding.' },
      { roundName: 'Tech Interview 1 & 2', focus: 'Graphs, BFS/DFS, Heaps, 2 LP questions', prepStrategy: 'Prepare 2 unique STAR stories for each of the 16 Leadership Principles.' },
      { roundName: 'Bar Raiser Round', focus: 'System Design / Object Oriented Design + Deep LP scrutiny', prepStrategy: 'Demonstrate Customer Obsession, Ownership, and Bias for Action.' },
    ],
    preferredTechStack: ['Java', 'Python', 'AWS Services', 'Distributed Queues'],
    eligibilityCriteria: ['Open to CS, IT, ECE, EE branches', 'Minimum 6.5 CGPA in graduation'],
    insiderTips: 'Always tie your solutions back to the 16 Amazon Leadership Principles. If your code is optimal but your LP answers are weak, you will not pass.',
    targetTopics: ['Priority Queues / Heaps', 'Graph BFS / Matrix', '16 Leadership Principles', 'OOP Design (Parking Lot, LRU)'],
  },
  {
    id: 'uber',
    name: 'Uber',
    logo: 'https://www.uber.com/favicon.ico',
    category: 'Tier-1 Product',
    minCgpa: 7.5,
    avgCtc: '55 - 65 LPA ($160,000+)',
    dsaDifficulty: 'Hard',
    rounds: [
      { roundName: 'Coding Challenge (Codesignal)', focus: '4 algorithmic questions (General Coding Framework)', prepStrategy: 'Score 800+ on CodeSignal by completing Q1, Q2, Q4 then Q3.' },
      { roundName: 'Problem Solving & DSA', focus: 'Real-time routing algorithms, intervals, topological sort', prepStrategy: 'High emphasis on clean code structure and optimal time complexity.' },
      { roundName: 'System Architecture & Concurrency', focus: 'Rate limiting, geospatial indexing (H3), WebSockets', prepStrategy: 'Understand Redis geospatial queries and message brokers (Kafka).' },
    ],
    preferredTechStack: ['Go', 'Java', 'Kafka', 'Redis', 'Microservices'],
    eligibilityCriteria: ['Strong mathematics and distributed computing foundations'],
    insiderTips: 'Uber engineers love asking about geospatial tracking, interval overlaps, and concurrency race conditions.',
    targetTopics: ['Intervals', 'Concurrency & Locks', 'Topological Sort', 'Geospatial Indexing'],
  },
  {
    id: 'atlassian',
    name: 'Atlassian',
    logo: 'https://www.atlassian.com/favicon.ico',
    category: 'Tier-1 Product',
    minCgpa: 7.0,
    avgCtc: '52 - 62 LPA ($150,000+)',
    dsaDifficulty: 'Medium-Hard',
    rounds: [
      { roundName: 'HackerRank Challenge', focus: '3 Data structures problems + MCQs', prepStrategy: 'Practice medium Trie, Hash Map, and Sliding Window problems.' },
      { roundName: 'Data Structures Round', focus: 'Trie autocomplete, File system modeling, Hash Maps', prepStrategy: 'Clean object-oriented design and naming.' },
      { roundName: 'System Design & Craft', focus: 'Collaborative real-time editing, document indexing', prepStrategy: 'Discuss Operational Transformation or CRDT concepts.' },
      { roundName: 'Values Interview', focus: 'Open company no bullshit, build with heart and balance', prepStrategy: 'Be candid, collaborative, and authentic.' },
    ],
    preferredTechStack: ['Java', 'Kotlin', 'React', 'AWS', 'PostgreSQL'],
    eligibilityCriteria: ['Min 7.0 CGPA throughout 10th, 12th, and Degree'],
    insiderTips: 'Atlassian values clean, production-level, unit-testable code. Write comments, modular helper functions, and handle exceptions.',
    targetTopics: ['Trie & Prefix Trees', 'Object Oriented Design', 'Collaborative Systems', 'Hash Maps'],
  },
];

export const UPCOMING_DEADLINES: JobDeadline[] = [
  {
    id: 'google-swe-intern',
    company: 'Google',
    role: 'Software Engineering Intern (Summer 2026)',
    type: 'Internship',
    location: 'Bangalore / Hyderabad / Sunnyvale (Hybrid)',
    deadlineDate: '2026-09-28',
    daysLeft: 21,
    ctcOffer: 'Stipend: ₹1,25,000 / month ($8,500/mo)',
    eligibility: 'Pre-final year students (2027 Graduating Batch)',
    applyLink: 'https://careers.google.com',
    batch: '2027 Batch',
    tags: ['FAANG', 'Paid Relocation', 'High PPO Rate'],
    isBookmarked: true,
  },
  {
    id: 'microsoft-engage-grad',
    company: 'Microsoft',
    role: 'Software Engineer - Full Time Graduate',
    type: 'Full-Time',
    location: 'Hyderabad / Noida / Redmond',
    deadlineDate: '2026-09-20',
    daysLeft: 13,
    ctcOffer: 'CTC: 44.5 LPA ($135k base + equity)',
    eligibility: 'Final year B.Tech/M.Tech (2026 Batch)',
    applyLink: 'https://careers.microsoft.com',
    batch: '2026 Batch',
    tags: ['Tier 1', 'Sign-on Bonus', 'Open to All Branches'],
    isBookmarked: true,
  },
  {
    id: 'amazon-sde-hiring',
    company: 'Amazon',
    role: 'Software Development Engineer 1 (Off-Campus)',
    type: 'Full-Time',
    location: 'Bangalore / Chennai / Seattle',
    deadlineDate: '2026-09-18',
    daysLeft: 11,
    ctcOffer: 'CTC: 42 LPA ($140k total comp)',
    eligibility: '2025 & 2026 Batch Graduates, Min 6.5 CGPA',
    applyLink: 'https://amazon.jobs',
    batch: '2025/2026 Batch',
    tags: ['Immediate Hiring', 'Mass Openings'],
    isBookmarked: false,
  },
  {
    id: 'uber-star-intern',
    company: 'Uber',
    role: 'Software Engineer Intern (Fall/Spring/Summer)',
    type: 'Internship',
    location: 'Bangalore / San Francisco',
    deadlineDate: '2026-10-05',
    daysLeft: 28,
    ctcOffer: 'Stipend: ₹1,50,000 / month ($9,500/mo)',
    eligibility: 'B.Tech/Dual Degree 3rd & 4th year',
    applyLink: 'https://uber.com/careers',
    batch: '2026/2027 Batch',
    tags: ['Highest Stipend', 'Product Tech'],
    isBookmarked: false,
  },
  {
    id: 'goldman-sachs-campus',
    company: 'Goldman Sachs',
    role: 'Summer Analyst - Global Markets & Engineering',
    type: 'Internship',
    location: 'Bengaluru / New York',
    deadlineDate: '2026-09-15',
    daysLeft: 8,
    ctcOffer: 'Stipend: ₹1,00,000 / month',
    eligibility: 'Open to All Branches, Min 7.0 CGPA',
    applyLink: 'https://goldmansachs.com/careers',
    batch: '2027 Batch',
    tags: ['Fintech', 'Quant & Systems', 'Expiring Soon'],
    isBookmarked: true,
  },
];

export const STUDY_SHEETS: StudySheet[] = [
  {
    id: 'os-core',
    category: 'Operating Systems',
    title: 'Operating Systems: Process, Threads, Memory & Deadlocks',
    readTime: '12 min read',
    keyTakeaways: [
      'Processes have independent virtual address spaces; threads within the same process share heap, code, and global memory, but have their own stack and registers.',
      'Deadlock requires 4 simultaneous Coffman conditions: Mutual Exclusion, Hold and Wait, No Preemption, Circular Wait.',
      'Paging eliminates external fragmentation through fixed-size blocks, but can introduce internal fragmentation.',
      'Context switching overhead involves saving PCB/registers and flushing TLB (Translation Lookaside Buffer).',
    ],
    contentMarkdown: `### 1. Process vs. Thread
- **Process**: An executing instance of a program with its own address space (Text, Data, Heap, Stack). Managed via Process Control Block (PCB).
- **Thread**: The smallest schedulable execution unit within a process (Thread Control Block - TCB). Threads share the heap and data segments, reducing context-switch cost significantly compared to inter-process switching.

### 2. Virtual Memory & Paging
Virtual memory gives each program the illusion of contiguous, dedicated RAM:
- **Pages & Frames**: Virtual memory is partitioned into fixed-size **Pages** (e.g. 4KB); physical RAM is split into corresponding **Frames**.
- **Page Fault**: Occurs when a referenced page is not currently in physical memory. The OS trap handler loads the page from disk into a free frame and updates the Page Table.
- **Thrashing**: Occurs when the system spends more time swapping pages in and out of disk than executing instructions, caused by insufficient physical memory for the active working set.

### 3. Deadlock Prevention & Resolution
4 Coffman conditions:
1. **Mutual Exclusion**: Non-shareable resource.
2. **Hold and Wait**: Process holds one resource while requesting another.
3. **No Preemption**: Resources cannot be forcibly taken away.
4. **Circular Wait**: A cyclic chain of processes each waiting for a resource held by the next.

*Eliminate any ONE condition to guarantee prevention.* Banker’s Algorithm is used for deadlock avoidance in safe state verification.`,
    commonInterviewQuestions: [
      {
        question: 'What happens during a context switch between two processes?',
        answerSummary: 'The OS saves current process CPU registers and program counter to its PCB, invalidates/flushes the TLB cache, changes memory mapping to the new process, loads the new process registers, and resumes execution.',
      },
      {
        question: 'Explain Mutex vs. Counting Semaphore with a real-life analogy.',
        answerSummary: 'A Mutex is like a single key to a bathroom (only the person holding the key can enter and must return it). A Semaphore is like a parking lot with N tickets available (any thread can decrement or increment the counter).',
      },
    ],
  },
  {
    id: 'dbms-core',
    category: 'DBMS & SQL',
    title: 'DBMS: ACID Properties, B-Tree Indexing & Normalization',
    readTime: '15 min read',
    keyTakeaways: [
      'ACID guarantees reliability: Atomicity (all-or-nothing), Consistency (integrity constraints), Isolation (concurrent execution), Durability (persisted to non-volatile disk via WAL).',
      'B+ Trees are preferred over Hash Indexes for disk storage because they provide O(log N) range queries with sequential leaf node pointers.',
      'Normalization (1NF -> 2NF -> 3NF -> BCNF) eliminates insertion, deletion, and update anomalies by decomposing tables based on functional dependencies.',
    ],
    contentMarkdown: `### 1. ACID Properties
- **Atomicity**: Entire transaction succeeds or is fully rolled back (handled via Write-Ahead Logging / Undo Logs).
- **Consistency**: Database transitions only between valid states conforming to all schema constraints and foreign keys.
- **Isolation Levels**:
  1. *Read Uncommitted* (Dirty reads possible)
  2. *Read Committed* (Non-repeatable reads possible)
  3. *Repeatable Read* (Phantom reads possible; default in MySQL InnoDB via MVCC)
  4. *Serializable* (Highest isolation, strictly sequential locking)
- **Durability**: Once committed, changes survive system crashes (persisted to Redo Log / disk).

### 2. Database Indexing: Why B+ Trees?
- B+ Trees maintain balanced depth, allowing disk seeks to remain minimal (usually 3 to 4 disk I/O operations for millions of rows).
- In B+ Trees, all data records are stored exclusively in the **leaf nodes**, which are linked as a doubly-linked list. This enables ultra-fast range queries: \`SELECT * FROM users WHERE age BETWEEN 20 AND 30;\`.

### 3. Normalization Summary
- **1NF**: Atomic column values, no repeating groups.
- **2NF**: In 1NF and no partial dependencies (every non-prime attribute depends on the full composite primary key).
- **3NF**: In 2NF and no transitive dependencies (X -> Y and Y -> Z).
- **BCNF**: For every functional dependency X -> Y, X must be a super key.`,
    commonInterviewQuestions: [
      {
        question: 'What is the difference between Clustered and Non-Clustered Index?',
        answerSummary: 'A Clustered index defines the physical order of data rows on disk (only 1 per table). A Non-Clustered index creates a separate B+ tree storing pointers/primary keys to the actual physical rows (can have multiple).',
      },
      {
        question: 'When would you pick NoSQL over a Relational SQL database?',
        answerSummary: 'Pick NoSQL when you have unstructured or rapidly evolving schemas, need horizontal partition scale across hundreds of nodes (e.g. Cassandra/DynamoDB), or need ultra-low-latency key-value lookups (Redis).',
      },
    ],
  },
  {
    id: 'cn-core',
    category: 'Computer Networks',
    title: 'Computer Networks: OSI/TCP Model, TCP 3-Way Handshake & HTTP/3',
    readTime: '10 min read',
    keyTakeaways: [
      'TCP guarantees reliable, ordered, and error-checked byte delivery via sequence numbers and ACKs; UDP provides low-latency, connectionless, unacknowledged datagrams.',
      'The TCP 3-way handshake: SYN -> SYN-ACK -> ACK establishes sequence numbers and socket buffers.',
      'HTTP/1.1 uses persistent TCP with head-of-line blocking; HTTP/2 uses multiplexed streams over 1 TCP connection; HTTP/3 runs over QUIC (UDP) to eliminate TCP head-of-line blocking.',
    ],
    contentMarkdown: `### 1. TCP 3-Way Handshake
1. **Client -> Server**: \`SYN\` (Synchronize sequence number X).
2. **Server -> Client**: \`SYN-ACK\` (Server sends sequence number Y and acknowledges X+1).
3. **Client -> Server**: \`ACK\` (Client acknowledges Y+1). Connection established!

### 2. What happens when you type google.com into your browser?
1. **URL Parsing & HSTS Check**: Browser checks browser cache, OS DNS cache, hosts file.
2. **DNS Resolution**: Recursive resolver queries Root DNS (.), TLD (.com), and Authoritative nameservers to resolve IP.
3. **TCP Handshake**: Sockets initialize via 3-way handshake on port 443.
4. **TLS 1.3 Handshake**: Key exchange via Elliptic Curve Diffie-Hellman (ECDHE), server sends certificate signed by CA.
5. **HTTP GET Request**: Browser sends HTTP request headers.
6. **Server Response**: Reverse proxy (Nginx/Envoy) forwards to application server; HTTP 200 payload returned.
7. **Browser Rendering**: DOM and CSSOM parsed, render tree constructed, layout calculated, and pixels painted.`,
    commonInterviewQuestions: [
      {
        question: 'Why does TCP need a 4-way handshake to terminate a connection?',
        answerSummary: 'TCP is full-duplex. Closing one direction (FIN -> ACK) allows the other party to finish transmitting remaining data before closing its half (FIN -> ACK).',
      },
    ],
  },
];

export const LEADERBOARD_DATA: LeaderboardUser[] = [
  { rank: 1, id: 'user-1', name: 'Arjun Sharma', college: 'IIT Bombay', solvedCount: 487, xp: 14850, streakDays: 142, badge: 'Grandmaster', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80' },
  { rank: 2, id: 'user-2', name: 'Priya Iyer', college: 'BITS Pilani', solvedCount: 462, xp: 13920, streakDays: 98, badge: 'Master', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80' },
  { rank: 3, id: 'user-3', name: 'Rohan Verma', college: 'IIIT Hyderabad', solvedCount: 430, xp: 12840, streakDays: 74, badge: 'Master', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=120&q=80' },
  { rank: 4, id: 'user-4', name: 'Neha Gupta', college: 'DTU Delhi', solvedCount: 395, xp: 11650, streakDays: 61, badge: 'Candidate Master', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=120&q=80' },
  { rank: 5, id: 'user-me', name: 'You (Alex Chen)', college: 'NIT Trichy', solvedCount: 148, xp: 4820, streakDays: 19, badge: 'Knight', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80', isCurrentUser: true },
  { rank: 6, id: 'user-6', name: 'Siddharth Nair', college: 'VIT Vellore', solvedCount: 340, xp: 9940, streakDays: 45, badge: 'Knight', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80' },
  { rank: 7, id: 'user-7', name: 'Ananya Roy', college: 'Jadavpur University', solvedCount: 312, xp: 9100, streakDays: 38, badge: 'Knight', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80' },
];

export const PORTFOLIO_BLUEPRINTS: PortfolioBlueprint[] = [
  {
    id: 'portfolio-1',
    title: 'Distributed In-Memory Key-Value Store with Raft Consensus',
    category: 'Backend Systems & Infra',
    difficulty: 'Advanced',
    tagline: 'Build a miniature Redis + etcd clone demonstrating network RPCs, log replication, and leader elections.',
    whyRecruitersHire: 'Recruiters reject basic CRUD apps. A distributed consensus system shows you understand CAP theorem, network partitions, TCP socket protocols, and crash recovery.',
    architecturePoints: [
      'Raft consensus algorithm implemented from scratch (Heartbeats, Leader Election, Log Replication)',
      'Custom binary protocol serializer for high throughput over raw TCP sockets',
      'Append-Only File (AOF) persistence engine for crash recovery',
      'Jepsen test suite simulation for simulated split-brain partitions',
    ],
    techStack: ['Go / C++ / Rust', 'gRPC / Protocol Buffers', 'Docker', 'Prometheus'],
    keyFeatures: [
      'Sub-2ms P99 write latency under cluster replication',
      'Graceful leader failover handling in under 150ms',
      'Concurrent read linearizability via lease read mechanisms',
    ],
    atsResumeBullet: 'Architected a distributed key-value store using Raft consensus in Go; achieved sub-2ms write latency across 5-node cluster with 100% linearizability under simulated network partitions.',
    githubTemplateIdea: 'Include a visual CLI dashboard, automated docker-compose test runner, and latency graphs.',
  },
  {
    id: 'portfolio-2',
    title: 'Real-Time Collaborative Code Sandbox with Sandboxed Docker Runners',
    category: 'Full Stack & Distributed',
    difficulty: 'Advanced',
    tagline: 'A browser-based multi-user IDE with remote Docker execution, WebSockets, and CRDT synchronization.',
    whyRecruitersHire: 'Demonstrates concurrency, WebSockets, container isolation security (preventing fork bombs and malicious system calls), and real-time state synchronization (Yjs / Automerge).',
    architecturePoints: [
      'Conflict-free Replicated Data Types (CRDTs) for multi-cursor collaborative code editing',
      'Isolated ephemeral Docker containers with cgroup CPU/memory limits and seccomp profile restrictions',
      'WebSocket gateway with Redis Pub/Sub backplane for multi-server scalability',
      'Server-Sent Events (SSE) for streaming stdout/stderr outputs to browser',
    ],
    techStack: ['TypeScript', 'Node.js', 'Docker API', 'Redis Pub/Sub', 'React', 'TailwindCSS'],
    keyFeatures: [
      'Safely executes arbitrary student code in 4 languages with 2-second timeout guarantees',
      'Handles 50+ concurrent typing peers without cursor desynchronization',
      'Zero-leak container recycling lifecycle',
    ],
    atsResumeBullet: 'Engineered a real-time collaborative coding sandbox supporting 50+ concurrent users with CRDTs and containerized execution; enforced strict cgroup CPU/memory quotas, maintaining 99.9% uptime.',
    githubTemplateIdea: 'Provide demo video gif, architecture diagram, and one-click deployment via Docker.',
  },
  {
    id: 'portfolio-3',
    title: 'High-Throughput Distributed Rate Limiter & API Gateway',
    category: 'Backend Systems & Infra',
    difficulty: 'Intermediate',
    tagline: 'Production-ready API reverse proxy with sliding window rate limiting, JWT validation, and Grafana telemetry.',
    whyRecruitersHire: 'Addresses standard system design interview questions with actual working implementation and load testing benchmarks (handling 25k QPS).',
    architecturePoints: [
      'Sliding window log and token bucket algorithms implemented via Redis Lua scripts (atomic execution)',
      'Dynamic routing and circuit breaker pattern (Netflix Hystrix style)',
      'Prometheus exporter for request rates, 429 rate limit drops, and P95 latency metrics',
      'Benchmarked using Apache JMeter and k6 load testing scripts',
    ],
    techStack: ['Node.js / Go', 'Redis Cluster', 'Prometheus', 'Grafana', 'Docker'],
    keyFeatures: [
      'Zero race conditions under distributed concurrency via atomic Lua scripts',
      'Protects downstream microservices against DoS bursts',
      'Comprehensive Grafana dashboard visualizing live RPS and latency spikes',
    ],
    atsResumeBullet: 'Designed and load-tested an API Gateway handling 20,000+ requests/sec using Redis atomic Lua scripts; reduced downstream service overload errors by 98% with sliding-window rate limiting.',
    githubTemplateIdea: 'Include reproducible k6 load-testing scripts and Grafana dashboard JSON exports.',
  },
];

export const FORUM_POSTS: ForumPost[] = [
  {
    id: 'post-1',
    title: 'How to tackle DP on Trees for Google & Uber interviews?',
    body: 'I am comfortable with 1D and 2D grid DP, but when questions like "Binary Tree Maximum Path Sum" or "House Robber III" appear, I struggle with what to return in recursive calls vs what to store in global variables. What is the standard mental model?',
    author: 'Kunal Singhania',
    authorCollege: 'IIT Roorkee',
    tags: ['Dynamic Programming', 'Trees', 'Google', 'Interview Experience'],
    createdAt: '2 hours ago',
    upvotes: 34,
    hasAcceptedAnswer: true,
    views: 312,
    replies: [
      {
        id: 'reply-1',
        author: 'Arjun Sharma (PlacementPrep Mentor)',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
        content: `The key mental model for DP on Trees is Post-Order Traversal (Bottom-Up):
1. **Define Subproblem**: What does child return to parent? Usually it is the optimal path that can EXTEND upwards through the parent.
2. **Global Update**: At the current node, calculate the value of the path passing THROUGH the node (Left Path + Node + Right Path), and update a global maximum \`maxSum = max(maxSum, left + right + node.val)\`.
3. **Return to Parent**: Only return \`node.val + max(left, right, 0)\` because a valid path cannot branch twice at the parent!`,
        createdAt: '1 hour ago',
        isAccepted: true,
        upvotes: 28,
      },
    ],
  },
  {
    id: 'post-2',
    title: 'Microsoft Codility OA: Does it test exact time complexity or just correctness?',
    body: 'Just gave my Microsoft campus test yesterday. Passed all sample test cases, but I am worried about hidden performance tests. Does Codility disqualify for O(N^2) if constraints were 10^5?',
    author: 'Sanya Malhotra',
    authorCollege: 'NIT Surathkal',
    tags: ['Microsoft', 'OA Experience', 'Codility'],
    createdAt: '5 hours ago',
    upvotes: 19,
    hasAcceptedAnswer: false,
    views: 189,
    replies: [
      {
        id: 'reply-2',
        author: 'Vikram Joshi',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
        content: 'Yes! Codility splits scores into 50% Correctness and 50% Performance. For N = 10^5, an O(N^2) solution will hit Time Limit Exceeded (TLE) on performance test cases and get only ~50% score.',
        createdAt: '4 hours ago',
        isAccepted: false,
        upvotes: 14,
      },
    ],
  },
];

export const PEER_SNIPPETS: PeerReviewSnippet[] = [
  {
    id: 'snippet-1',
    author: 'Tanvi Patel',
    title: 'Sliding Window Maximum (O(N) with Monotonic Deque)',
    language: 'javascript',
    code: `function maxSlidingWindow(nums, k) {
  const result = [];
  const deque = []; // Stores indices of elements in decreasing order

  for (let i = 0; i < nums.length; i++) {
    // 1. Remove elements outside the current window [i - k + 1, i]
    while (deque.length > 0 && deque[0] < i - k + 1) {
      deque.shift();
    }

    // 2. Remove smaller elements as they are dominated by nums[i]
    while (deque.length > 0 && nums[deque[deque.length - 1]] < nums[i]) {
      deque.pop();
    }

    deque.push(i);

    // 3. Add to result once window reaches size k
    if (i >= k - 1) {
      result.push(nums[deque[0]]);
    }
  }

  return result;
}`,
    comments: [
      {
        id: 'c-1',
        author: 'Alex (Senior Mentor)',
        line: 8,
        comment: 'Tip for JS: Array.shift() is O(N). In production, consider a two-pointer head index or doubly-linked list for true O(1) pops!',
        timestamp: '10 min ago',
      },
      {
        id: 'c-2',
        author: 'Rohan',
        line: 12,
        comment: 'Clean monotonic queue pattern! Very easy to read.',
        timestamp: '5 min ago',
      },
    ],
  },
];

export const INITIAL_COLLABORATIVE_SPACES = [
  {
    id: 'space-1',
    projectTitle: 'Distributed In-Memory Key-Value Store with Raft Consensus',
    description: 'Collaborative team implementing peer heartbeats, log compaction, and lease-based linearizable read paths in Go.',
    techStack: 'Go / gRPC / Docker',
    membersCount: 4,
    activeCodeSnippet: `// Raft Node Election State Machine
package consensus

import (
  "sync"
  "time"
)

type NodeState int
const (
  Follower NodeState = iota
  Candidate
  Leader
)

type RaftNode struct {
  mu          sync.Mutex
  currentTerm int
  votedFor    string
  state       NodeState
  electionTimer *time.Timer
}

func (rn *RaftNode) StartElection() {
  rn.mu.Lock()
  defer rn.mu.Unlock()
  rn.state = Candidate
  rn.currentTerm++
  rn.votedFor = "self"
  // Broadcast RequestVote RPCs across all peers...
}`,
    reviewComments: [
      {
        id: 'rc-1',
        author: 'Vikram',
        comment: 'Ensure election timer is randomized between 150ms-300ms to avoid split vote ties.',
        timestamp: '15 min ago',
      },
      {
        id: 'rc-2',
        author: 'Sanya',
        comment: 'Add a check to verify if majority quorum (N/2 + 1) accepted the vote before promoting to Leader.',
        timestamp: '8 min ago',
      },
    ],
  },
  {
    id: 'space-2',
    projectTitle: 'Real-Time Collaborative Code Sandbox & Container Isolation',
    description: 'Building multi-cursor CRDT sync with Docker cgroups and WebSocket broker in TypeScript.',
    techStack: 'TypeScript / Node.js / Docker API',
    membersCount: 3,
    activeCodeSnippet: `// Docker Runner Sandbox Runner
import Docker from 'dockerode';

export async function executeInEphemeralContainer(code: string, lang: string) {
  const docker = new Docker();
  const container = await docker.createContainer({
    Image: 'sandbox-runner-' + lang,
    HostConfig: {
      Memory: 128 * 1024 * 1024, // 128MB ceiling
      NanoCpus: 1000000000,       // Max 1 vCPU
      NetworkMode: 'none',        // Zero egress network access
    },
    Cmd: ['sh', '-c', code],
  });
  return container;
}`,
    reviewComments: [
      {
        id: 'rc-3',
        author: 'Arjun',
        comment: 'Security tip: add --pids-limit=64 to completely mitigate fork bomb vulnerability attacks.',
        timestamp: '1 hour ago',
      },
    ],
  },
];

export const INITIAL_ROADMAP_PHASES = ROADMAP_PHASES;
export const INITIAL_STUDY_SHEETS = STUDY_SHEETS;
export const INITIAL_COMPANIES = COMPANY_HIRING_DATA;
export const INITIAL_JOB_DEADLINES = UPCOMING_DEADLINES;
export const INITIAL_LEADERBOARD = LEADERBOARD_DATA.map((u) => ({
  ...u,
  problemsSolved: u.solvedCount || 100,
}));
export const INITIAL_FORUM_POSTS = FORUM_POSTS.map((p) => ({
  ...p,
  content: p.body || '',
  category: p.tags[0] || 'Data Structures & Algorithms',
}));

