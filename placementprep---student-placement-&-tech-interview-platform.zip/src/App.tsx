import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { CodingArena } from './components/CodingArena';
import { AIMockInterview } from './components/AIMockInterview';
import { RoadmapView } from './components/RoadmapView';
import { CompanyCriteriaView } from './components/CompanyCriteriaView';
import { ProgressAnalytics } from './components/ProgressAnalytics';
import { ResumeBuilder } from './components/ResumeBuilder';
import { DiscussionForum } from './components/DiscussionForum';
import { LeaderboardView } from './components/LeaderboardView';
import { CollaborativeProjects } from './components/CollaborativeProjects';

import {
  INITIAL_PROBLEMS,
  INITIAL_ROADMAP_PHASES,
  INITIAL_STUDY_SHEETS,
  INITIAL_COMPANIES,
  INITIAL_JOB_DEADLINES,
  INITIAL_LEADERBOARD,
  INITIAL_FORUM_POSTS,
  INITIAL_COLLABORATIVE_SPACES,
} from './data/mockData';

import {
  loadOfflineData,
  saveOfflineData,
  OFFLINE_KEYS,
} from './utils/offlineStorage';
import { JobDeadline, ForumPost } from './types';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('arena');

  // Dark Mode State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const cachedTheme = loadOfflineData<'light' | 'dark'>('theme', 'light');
    if (cachedTheme === 'dark') {
      document.documentElement.classList.add('dark');
      return true;
    }
    return false;
  });

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
        saveOfflineData('theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        saveOfflineData('theme', 'light');
      }
      return next;
    });
  };

  // Gamification & Progress State
  const [xp, setXp] = useState<number>(() => {
    return loadOfflineData<number>('user_xp', 2450);
  });

  const [streakDays, setStreakDays] = useState<number>(() => {
    return loadOfflineData<number>('streak_days', 14);
  });

  const [totalSolved, setTotalSolved] = useState<number>(() => {
    return loadOfflineData<number>('total_solved', 148);
  });

  // App Data Collections
  const [problems, setProblems] = useState(INITIAL_PROBLEMS);
  const [jobDeadlines, setJobDeadlines] = useState<JobDeadline[]>(() => {
    return loadOfflineData<JobDeadline[]>(OFFLINE_KEYS.DEADLINES, INITIAL_JOB_DEADLINES);
  });
  const [forumPosts, setForumPosts] = useState<ForumPost[]>(INITIAL_FORUM_POSTS);
  const [collabSpaces, setCollabSpaces] = useState(INITIAL_COLLABORATIVE_SPACES);

  // Sync to offline storage when updated
  const handleSolveProblem = (problemId: string, xpEarned: number) => {
    setXp((prev) => {
      const updated = prev + xpEarned;
      saveOfflineData('user_xp', updated);
      return updated;
    });
    setTotalSolved((prev) => {
      const updated = prev + 1;
      saveOfflineData('total_solved', updated);
      return updated;
    });
  };

  const handleToggleDeadlineBookmark = (deadlineId: string) => {
    setJobDeadlines((prev) => {
      const updated = prev.map((d) =>
        d.id === deadlineId ? { ...d, isBookmarked: !d.isBookmarked } : d
      );
      saveOfflineData(OFFLINE_KEYS.DEADLINES, updated);
      return updated;
    });
  };

  const handleAddCustomDeadline = (deadline: JobDeadline) => {
    setJobDeadlines((prev) => {
      const updated = [deadline, ...prev];
      saveOfflineData(OFFLINE_KEYS.DEADLINES, updated);
      return updated;
    });
  };

  const handleAddForumPost = (newPost: ForumPost) => {
    setForumPosts((prev) => [newPost, ...prev]);
  };

  const handleUpvoteForumPost = (postId: string) => {
    setForumPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, upvotes: p.upvotes + 1 } : p))
    );
  };

  const handleAddCollabComment = (spaceId: string, author: string, comment: string) => {
    setCollabSpaces((prev) =>
      prev.map((s) => {
        if (s.id === spaceId) {
          return {
            ...s,
            reviewComments: [
              ...s.reviewComments,
              {
                id: 'c-' + Date.now(),
                author,
                comment,
                timestamp: 'Just now',
              },
            ],
          };
        }
        return s;
      })
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors flex flex-col font-sans">
      {/* Universal Responsive Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onSelectTab={setActiveTab}
        isDark={isDarkMode}
        isDarkMode={isDarkMode}
        toggleDarkMode={toggleDarkMode}
        onToggleDarkMode={toggleDarkMode}
        xp={xp}
        streakDays={streakDays}
        totalSolved={totalSolved}
        deadlines={jobDeadlines}
      />

      {/* Main Content View Container */}
      <main className="flex-1 pb-16">
        {(activeTab === 'arena' || activeTab === 'coding') && (
          <CodingArena
            problems={problems}
            onSolveProblem={handleSolveProblem}
          />
        )}

        {activeTab === 'interview' && <AIMockInterview />}

        {activeTab === 'roadmap' && (
          <RoadmapView
            phases={INITIAL_ROADMAP_PHASES}
            studySheets={INITIAL_STUDY_SHEETS}
          />
        )}

        {(activeTab === 'criteria' || activeTab === 'companies') && (
          <CompanyCriteriaView
            companies={INITIAL_COMPANIES}
            deadlines={jobDeadlines}
            onToggleBookmark={handleToggleDeadlineBookmark}
            onAddCustomDeadline={handleAddCustomDeadline}
          />
        )}

        {activeTab === 'analytics' && (
          <ProgressAnalytics
            totalSolved={totalSolved}
            xp={xp}
            streakDays={streakDays}
          />
        )}

        {activeTab === 'resume' && <ResumeBuilder />}

        {activeTab === 'forum' && (
          <DiscussionForum
            posts={forumPosts}
            onAddPost={handleAddForumPost}
            onUpvotePost={handleUpvoteForumPost}
          />
        )}

        {activeTab === 'leaderboard' && (
          <LeaderboardView
            users={INITIAL_LEADERBOARD}
            currentUserId="user-alex"
          />
        )}

        {(activeTab === 'projects' || activeTab === 'collab') && (
          <CollaborativeProjects
            spaces={collabSpaces}
            onAddReviewComment={handleAddCollabComment}
          />
        )}
      </main>

      {/* Clean Footer */}
      <footer className="print:hidden border-t border-slate-200 dark:border-slate-800/80 bg-white/50 dark:bg-slate-900/50 py-4 px-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© 2026 PlacementPrep • Comprehensive Placement & Career Suite for Engineers</p>
          <div className="flex items-center gap-4 text-[11px] font-semibold">
            <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" /> Offline Storage Ready
            </span>
            <span>Gemini 3.8 Flash Powered</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
