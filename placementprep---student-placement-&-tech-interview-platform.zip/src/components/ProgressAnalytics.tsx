import React from 'react';
import {
  TrendingUp,
  Award,
  CheckCircle2,
  Calendar,
  Zap,
  Target,
  BarChart2,
  Flame,
  Layers,
  ArrowUpRight,
  ShieldCheck,
} from 'lucide-react';

interface ProgressAnalyticsProps {
  totalSolved: number;
  xp: number;
  streakDays: number;
}

export const ProgressAnalytics: React.FC<ProgressAnalyticsProps> = ({
  totalSolved,
  xp,
  streakDays,
}) => {
  // Skill Proficiencies
  const skills = [
    { name: 'Data Structures & Algorithms', score: 82, target: 90, color: 'bg-indigo-600' },
    { name: 'System Design & Distributed Systems', score: 71, target: 80, color: 'bg-blue-600' },
    { name: 'Operating Systems & Concurrency', score: 78, target: 85, color: 'bg-cyan-600' },
    { name: 'DBMS, SQL & Indexing', score: 85, target: 85, color: 'bg-emerald-600' },
    { name: 'Computer Networks (OSI/TCP)', score: 74, target: 80, color: 'bg-amber-600' },
    { name: 'Behavioral & STAR Method', score: 88, target: 90, color: 'bg-purple-600' },
  ];

  // Target Company Readiness
  const companyReadiness = [
    { company: 'Google', readiness: 76, tier: 'Tier 1 FAANG', dsaTarget: 'Hard DP & Flow' },
    { company: 'Amazon', readiness: 84, tier: 'FAANG', dsaTarget: 'Graphs & 16 LPs' },
    { company: 'Microsoft', readiness: 86, tier: 'FAANG', dsaTarget: 'Trees & OS Core' },
    { company: 'Uber', readiness: 79, tier: 'Tier 1 Product', dsaTarget: 'Intervals & Locks' },
    { company: 'Atlassian', readiness: 88, tier: 'Tier 1 Product', dsaTarget: 'Tries & LLD Clean Code' },
  ];

  // Difficulty counts
  const easyCount = 68;
  const mediumCount = 62;
  const hardCount = totalSolved - (easyCount + mediumCount) > 0 ? totalSolved - (easyCount + mediumCount) : 18;

  // 30 days activity heatmap data
  const days = Array.from({ length: 35 }, (_, i) => {
    // Generate realistic activity frequency
    const solves = (i * 3 + (i % 4)) % 5;
    return {
      day: i + 1,
      solves: solves,
    };
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            <TrendingUp className="w-4 h-4" />
            <span>Personal Performance Dashboard</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight mt-1">
            Personalized Progress Analytics & Skill Radar
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Real-time telemetry tracking problem velocity, CS fundamentals mastery, and target company benchmark readiness.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-2.5 px-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800/80 text-xs font-bold text-indigo-700 dark:text-indigo-300 flex items-center gap-2">
            <Award className="w-4 h-4" />
            <span>Overall Placement Readiness: 82%</span>
          </div>
        </div>
      </div>

      {/* Top High-Impact Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Solved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-100">
            {totalSolved}
            <span className="text-xs text-slate-400 font-normal ml-1.5">/ 250 Target</span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
            <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${(totalSolved / 250) * 100}%` }} />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Current Streak</span>
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-100">
            {streakDays} Days
            <span className="text-xs text-emerald-600 font-bold ml-2">Top 5%</span>
          </div>
          <p className="text-[11px] text-slate-400">Longest: 28 days continuous</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Competitive XP</span>
            <Zap className="w-4 h-4 text-indigo-500 fill-indigo-500" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-100">
            {xp.toLocaleString()} XP
          </div>
          <p className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">Rank #5 on College Leaderboard</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Mock Rounds</span>
            <ShieldCheck className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-100">
            8 Completed
          </div>
          <p className="text-[11px] text-emerald-600 font-semibold">Avg Score: 84% (Hire Recommended)</p>
        </div>
      </div>

      {/* Main Grid: Skill Acquisition Radar & Target Company Readiness */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Skill Acquisition Progress Bars (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-indigo-500" />
              <span>Skill Mastery vs. Tier-1 Placement Benchmarks</span>
            </h3>
            <span className="text-[11px] font-medium text-slate-400">Target = 85%+</span>
          </div>

          <div className="space-y-4">
            {skills.map((skill) => (
              <div key={skill.name} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-700 dark:text-slate-300">{skill.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-900 dark:text-slate-100 font-mono font-bold">{skill.score}%</span>
                    <span className="text-slate-400 text-[10px] font-normal">Target: {skill.target}%</span>
                  </div>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden flex">
                  <div
                    className={`${skill.color} h-full rounded-full transition-all duration-700`}
                    style={{ width: `${skill.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Difficulty Breakdown Badges */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-800/60">
              <div className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">Easy</div>
              <div className="text-lg font-extrabold text-emerald-900 dark:text-emerald-200 mt-0.5">{easyCount}</div>
            </div>
            <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-800/60">
              <div className="text-[11px] font-semibold text-amber-800 dark:text-amber-300">Medium</div>
              <div className="text-lg font-extrabold text-amber-900 dark:text-amber-200 mt-0.5">{mediumCount}</div>
            </div>
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-800/60">
              <div className="text-[11px] font-semibold text-rose-800 dark:text-rose-300">Hard</div>
              <div className="text-lg font-extrabold text-rose-900 dark:text-rose-200 mt-0.5">{hardCount}</div>
            </div>
          </div>
        </div>

        {/* Right: Target Company Match Readiness Index (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Target className="w-4 h-4 text-indigo-500" />
              <span>Target Company Fit Matrix</span>
            </h3>
            <span className="text-[11px] text-slate-400">Based on past test clears</span>
          </div>

          <div className="space-y-3">
            {companyReadiness.map((c) => (
              <div
                key={c.company}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800/80 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-xs text-slate-900 dark:text-slate-100">{c.company}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                      {c.tier}
                    </span>
                  </div>
                  <span className="text-xs font-extrabold font-mono text-indigo-600 dark:text-indigo-400">
                    {c.readiness}% Fit
                  </span>
                </div>

                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      c.readiness >= 85 ? 'bg-emerald-500' : c.readiness >= 78 ? 'bg-indigo-500' : 'bg-amber-500'
                    }`}
                    style={{ width: `${c.readiness}%` }}
                  />
                </div>

                <div className="text-[10px] text-slate-500 flex items-center justify-between">
                  <span>Priority Gap: {c.dsaTarget}</span>
                  <span className="font-medium text-indigo-500 flex items-center">
                    Sprint <ArrowUpRight className="w-3 h-3 ml-0.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 30-Day Activity Heatmap */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              35-Day Consistency Activity Heatmap
            </h3>
          </div>
          <span className="text-xs text-slate-400">Continuous Daily Practice</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 pt-2">
          {days.map((d) => {
            const level = d.solves === 0 ? 'bg-slate-100 dark:bg-slate-800' : d.solves === 1 ? 'bg-emerald-200 dark:bg-emerald-950' : d.solves <= 3 ? 'bg-emerald-400 dark:bg-emerald-700' : 'bg-emerald-600 dark:bg-emerald-500';
            return (
              <div
                key={d.day}
                className={`w-5 h-5 sm:w-6 sm:h-6 rounded-md ${level} border border-slate-200/50 dark:border-slate-700/50 flex items-center justify-center text-[9px] font-mono text-slate-600 dark:text-slate-300 cursor-pointer hover:ring-2 hover:ring-indigo-500 transition`}
                title={`Day ${d.day}: ${d.solves} coding tasks completed`}
              >
                {d.solves > 0 ? d.solves : ''}
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-end gap-2 text-[10px] text-slate-400 pt-1">
          <span>Less</span>
          <div className="w-3 h-3 rounded bg-slate-100 dark:bg-slate-800" />
          <div className="w-3 h-3 rounded bg-emerald-200 dark:bg-emerald-950" />
          <div className="w-3 h-3 rounded bg-emerald-400 dark:bg-emerald-700" />
          <div className="w-3 h-3 rounded bg-emerald-600 dark:bg-emerald-500" />
          <span>More</span>
        </div>
      </div>
    </div>
  );
};
