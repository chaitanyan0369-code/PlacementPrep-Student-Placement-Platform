import React, { useState } from 'react';
import {
  Trophy,
  Medal,
  Flame,
  Zap,
  CheckCircle2,
  Crown,
  Search,
  ArrowUp,
  ArrowDown,
  Sparkles,
} from 'lucide-react';
import { LeaderboardUser } from '../types';

interface LeaderboardViewProps {
  users: LeaderboardUser[];
  currentUserId?: string;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  users,
  currentUserId = 'user-alex',
}) => {
  const [filterCollege, setFilterCollege] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const sortedUsers = [...users].sort((a, b) => b.xp - a.xp);

  const top1 = sortedUsers[0];
  const top2 = sortedUsers[1];
  const top3 = sortedUsers[2];

  const filteredList = sortedUsers.filter((u) => {
    const matchSearch =
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.college.toLowerCase().includes(searchQuery.toLowerCase());
    return matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400">
            <Trophy className="w-4 h-4" />
            <span>Competitive Arena Standings</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight mt-1">
            Global Placement Prep Leaderboard
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Rankings updated dynamically based on coding challenge solves, streak retention, and AI mock evaluations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-2.5 px-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 text-xs font-bold text-amber-800 dark:text-amber-300 flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-500" />
            <span>Weekly Reward: Direct Interview Referral to Tier-1 Startups</span>
          </div>
        </div>
      </div>

      {/* Podium Top 3 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
        {/* Rank 2 (Silver) */}
        {top2 && (
          <div className="order-2 md:order-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-center space-y-3 shadow-sm flex flex-col justify-between">
            <div className="space-y-2">
              <div className="relative inline-block">
                <img
                  src={top2.avatar}
                  alt={top2.name}
                  className="w-16 h-16 rounded-full mx-auto border-3 border-slate-300 dark:border-slate-600 object-cover shadow-md"
                />
                <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-slate-300 text-slate-800 font-extrabold text-xs flex items-center justify-center border-2 border-white dark:border-slate-900">
                  2
                </span>
              </div>
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100">{top2.name}</h3>
              <p className="text-[11px] text-slate-500">{top2.college}</p>
              <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                {top2.badge}
              </span>
            </div>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-around text-xs font-mono">
              <div>
                <span className="text-slate-400 block text-[10px]">Solved</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{top2.problemsSolved}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Points</span>
                <span className="font-bold text-indigo-600 dark:text-indigo-400">{top2.xp} XP</span>
              </div>
            </div>
          </div>
        )}

        {/* Rank 1 (Gold) */}
        {top1 && (
          <div className="order-1 md:order-2 bg-gradient-to-b from-amber-500/10 via-amber-500/5 to-transparent bg-white dark:bg-slate-900 border-2 border-amber-400 dark:border-amber-500/60 rounded-3xl p-6 text-center space-y-3 shadow-lg shadow-amber-500/10 relative -translate-y-2 flex flex-col justify-between">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500 text-slate-950 px-3 py-0.5 rounded-full font-extrabold text-[10px] flex items-center gap-1 shadow-sm">
              <Crown className="w-3 h-3 fill-slate-950" /> CHAMPION
            </div>
            <div className="space-y-2 pt-2">
              <div className="relative inline-block">
                <img
                  src={top1.avatar}
                  alt={top1.name}
                  className="w-20 h-20 rounded-full mx-auto border-4 border-amber-400 object-cover shadow-lg"
                />
                <span className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center border-2 border-white dark:border-slate-900">
                  1
                </span>
              </div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">{top1.name}</h3>
              <p className="text-xs text-slate-500">{top1.college}</p>
              <span className="inline-block text-[11px] font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900 dark:bg-amber-950/80 dark:text-amber-200">
                {top1.badge}
              </span>
            </div>
            <div className="pt-3 border-t border-amber-200/50 dark:border-amber-800/50 flex justify-around text-xs font-mono">
              <div>
                <span className="text-slate-400 block text-[10px]">Solved</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{top1.problemsSolved}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Points</span>
                <span className="font-bold text-amber-600 dark:text-amber-400">{top1.xp} XP</span>
              </div>
            </div>
          </div>
        )}

        {/* Rank 3 (Bronze) */}
        {top3 && (
          <div className="order-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-center space-y-3 shadow-sm flex flex-col justify-between">
            <div className="space-y-2">
              <div className="relative inline-block">
                <img
                  src={top3.avatar}
                  alt={top3.name}
                  className="w-16 h-16 rounded-full mx-auto border-3 border-amber-700/60 object-cover shadow-md"
                />
                <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-700 text-white font-extrabold text-xs flex items-center justify-center border-2 border-white dark:border-slate-900">
                  3
                </span>
              </div>
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100">{top3.name}</h3>
              <p className="text-[11px] text-slate-500">{top3.college}</p>
              <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                {top3.badge}
              </span>
            </div>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-around text-xs font-mono">
              <div>
                <span className="text-slate-400 block text-[10px]">Solved</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{top3.problemsSolved}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Points</span>
                <span className="font-bold text-indigo-600 dark:text-indigo-400">{top3.xp} XP</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Global Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">
            All Student Competitors ({filteredList.length})
          </h3>
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search candidate name, college..."
              className="w-full text-xs pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800 uppercase text-[10px]">
              <tr>
                <th className="py-3 px-4">Rank</th>
                <th className="py-3 px-4">Candidate</th>
                <th className="py-3 px-4">Badge</th>
                <th className="py-3 px-4">College</th>
                <th className="py-3 px-4 text-center">Solved</th>
                <th className="py-3 px-4 text-center">Streak</th>
                <th className="py-3 px-4 text-right">Total XP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredList.map((user, idx) => {
                const isCurrentUser = user.id === currentUserId;
                const rankNum = idx + 1;
                return (
                  <tr
                    key={user.id}
                    className={`transition ${
                      isCurrentUser
                        ? 'bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-200 font-bold'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <td className="py-3.5 px-4 font-mono font-bold">
                      {rankNum === 1 ? (
                        <span className="text-amber-500 font-black">#1 🏆</span>
                      ) : rankNum === 2 ? (
                        <span className="text-slate-400 font-black">#2 🥈</span>
                      ) : rankNum === 3 ? (
                        <span className="text-amber-700 font-black">#3 🥉</span>
                      ) : (
                        `#${rankNum}`
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-7 h-7 rounded-full object-cover shrink-0"
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-900 dark:text-slate-100">
                              {user.name}
                            </span>
                            {isCurrentUser && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-600 text-white font-bold">
                                YOU
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                        {user.badge}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">{user.college}</td>
                    <td className="py-3.5 px-4 text-center font-mono font-bold">
                      {user.problemsSolved}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-flex items-center gap-1 text-amber-600 font-mono font-bold">
                        <Flame className="w-3.5 h-3.5 fill-amber-500" />
                        {user.streakDays}d
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {user.xp.toLocaleString()} XP
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
