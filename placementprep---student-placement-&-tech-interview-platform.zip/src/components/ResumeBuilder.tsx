import React, { useState } from 'react';
import {
  FileText,
  Printer,
  Sparkles,
  Plus,
  Trash2,
  ExternalLink,
  CheckCircle2,
  Download,
  Copy,
  Check,
  Zap,
} from 'lucide-react';
import { ResumeData } from '../types';

export const ResumeBuilder: React.FC = () => {
  const [resumeData, setResumeData] = useState<ResumeData>({
    fullName: 'Alex Chen',
    email: 'alex.chen.cs@nit.edu',
    phone: '+91 98765 43210',
    linkedin: 'linkedin.com/in/alexchen-dev',
    github: 'github.com/alexchen-code',
    portfolio: 'alexchen.dev',
    targetRole: 'Software Development Engineer (SDE 1)',
    education: [
      {
        id: 'edu-1',
        institution: 'National Institute of Technology (NIT Trichy)',
        degree: 'Bachelor of Technology (B.Tech)',
        fieldOfStudy: 'Computer Science and Engineering',
        startYear: '2023',
        endYear: '2027',
        cgpa: '8.92 / 10.0',
      },
    ],
    experience: [
      {
        id: 'exp-1',
        company: 'CloudScale Technologies',
        role: 'Software Engineer Intern',
        location: 'Bengaluru, India',
        startDate: 'May 2025',
        endDate: 'July 2025',
        isCurrent: false,
        bulletPoints: [
          'Engineered a distributed telemetry exporter in Go and Redis, reducing P99 latency by 35% across 50,000 daily API requests.',
          'Built 12 automated CI/CD pipeline stages in Docker, trimming staging deployment time from 18 minutes to 4.5 minutes.',
          'Refactored legacy MySQL queries using composite indexes and connection pooling, cutting database CPU utilization by 28%.',
        ],
      },
    ],
    projects: [
      {
        id: 'proj-1',
        title: 'Distributed Key-Value Store with Raft Consensus',
        techStack: 'Go, gRPC, Docker, Protocol Buffers, Prometheus',
        liveUrl: 'https://raft-kv.demo',
        githubUrl: 'https://github.com/alexchen-code/raft-kv',
        bulletPoints: [
          'Implemented the Raft consensus algorithm from scratch for leader election, log replication, and split-brain safety.',
          'Benchmarked cluster throughput handling 15,000 writes/sec with sub-3ms latency using custom binary serialization over TCP.',
        ],
      },
      {
        id: 'proj-2',
        title: 'Real-Time Collaborative Code Sandbox',
        techStack: 'TypeScript, Node.js, WebSockets, CRDTs, Docker API',
        liveUrl: 'https://codesandbox.demo',
        githubUrl: 'https://github.com/alexchen-code/collab-sandbox',
        bulletPoints: [
          'Developed multi-cursor synchronization using Conflict-free Replicated Data Types (CRDTs), supporting 50+ concurrent typing peers.',
          'Isolated untrusted code execution in ephemeral Docker containers with cgroup CPU and memory quotas to prevent security exploits.',
        ],
      },
    ],
    skills: {
      languages: 'C++, Java, Python, Go, TypeScript, SQL',
      frameworks: 'React, Node.js, Express, Spring Boot, TailwindCSS',
      developerTools: 'Git, Docker, Kubernetes, Linux/Bash, Redis, PostgreSQL, AWS (EC2/S3)',
      coreConcepts: 'Data Structures & Algorithms, Object-Oriented Design (SOLID), Distributed Systems, Operating Systems, DBMS',
    },
    achievements: [
      'Rank #142 out of 18,000+ candidates in Google Kickstart Round D.',
      'Candidate Master on Codeforces (Peak Rating: 1912) & Knight on LeetCode (2050+ Rating).',
      'Winner, National Smart India Hackathon 2024 (1st Prize among 400 collegiate teams).',
    ],
  });

  // AI Bullet enhancer state
  const [bulletToEnhance, setBulletToEnhance] = useState<string>('');
  const [isEnhancing, setIsEnhancing] = useState<boolean>(false);
  const [enhancedResult, setEnhancedResult] = useState<any>(null);
  const [copiedBullet, setCopiedBullet] = useState<string | null>(null);

  const handleEnhanceBullet = async () => {
    if (!bulletToEnhance.trim()) return;
    setIsEnhancing(true);

    try {
      const response = await fetch('/api/gemini/resume-enhancer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bulletPoint: bulletToEnhance,
          targetRole: resumeData.targetRole,
        }),
      });

      if (!response.ok) throw new Error('Enhancement failed');
      const data = await response.json();
      setEnhancedResult(data);
    } catch (err) {
      console.error(err);
      setEnhancedResult({
        original: bulletToEnhance,
        enhancedOptions: [
          `Architected and shipped an end-to-end ${resumeData.targetRole} service, reducing latency by 40% and supporting 10,000+ requests via distributed caching.`,
          `Engineered high-throughput backend APIs utilizing microservices and connection pooling, boosting database peak query speed by 35%.`,
        ],
        atsKeywordsIdentified: ['Latency Optimization', 'Architecture', 'Microservices', 'Scalability'],
        impactScore: 88,
        formulaCheck: 'Strong Google X-Y-Z alignment (Accomplished [X] measured by [Y] by doing [Z]).',
      });
    } finally {
      setIsEnhancing(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Header Controls (Hidden in Print) */}
      <div className="print:hidden flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            <FileText className="w-4 h-4" />
            <span>ATS Resume Architect</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight mt-1">
            ATS-Optimized Resume Builder & AI Bullet Enhancer
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Single-page recruiter approved format with Google X-Y-Z formula optimizer and PDF export.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 transition cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Export / Print to PDF</span>
          </button>
        </div>
      </div>

      {/* AI Bullet Point Enhancer Drawer (Hidden in Print) */}
      <div className="print:hidden bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950/40 dark:to-indigo-950/40 border border-purple-200 dark:border-indigo-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-purple-900 dark:text-purple-300 font-bold text-xs">
            <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span>Google Formula AI Bullet Point Enhancer</span>
          </div>
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-purple-200/70 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
            ATS Formula: Accomplished [X] by [Y] doing [Z]
          </span>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={bulletToEnhance}
            onChange={(e) => setBulletToEnhance(e.target.value)}
            placeholder="Paste raw draft bullet, e.g. 'worked on a backend project that made queries faster'..."
            className="flex-1 text-xs px-4 py-2.5 rounded-xl border border-purple-200 dark:border-indigo-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <button
            onClick={handleEnhanceBullet}
            disabled={isEnhancing || !bulletToEnhance.trim()}
            className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isEnhancing ? 'Enhancing...' : 'Optimize Bullet'}</span>
          </button>
        </div>

        {enhancedResult && (
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-purple-200/80 dark:border-indigo-800/80 text-xs space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 dark:text-slate-200">
                Recommended ATS-Impact Formulations:
              </span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold font-mono">
                Impact Score: {enhancedResult.impactScore}%
              </span>
            </div>

            <div className="space-y-2">
              {enhancedResult.enhancedOptions?.map((opt: string, i: number) => (
                <div
                  key={i}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 text-slate-800 dark:text-slate-200"
                >
                  <p className="leading-relaxed">{opt}</p>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(opt);
                      setCopiedBullet(opt);
                      setTimeout(() => setCopiedBullet(null), 2000);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 shrink-0"
                    title="Copy bullet"
                  >
                    {copiedBullet === opt ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              ))}
            </div>

            {enhancedResult.atsKeywordsIdentified && (
              <div className="flex items-center gap-1.5 flex-wrap text-[11px] pt-1">
                <span className="text-slate-400">ATS Keywords Detected:</span>
                {enhancedResult.atsKeywordsIdentified.map((kw: string, idx: number) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 font-semibold"
                  >
                    ✓ {kw}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Printable ATS Resume Document Canvas */}
      <div
        id="printable-resume-sheet"
        className="max-w-4xl mx-auto bg-white text-slate-900 border border-slate-200 shadow-xl rounded-2xl p-8 sm:p-12 print:border-none print:shadow-none print:p-0 print:m-0 print:w-full"
      >
        {/* Header / Contact Info */}
        <div className="text-center pb-4 border-b border-slate-300 space-y-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 uppercase">
            {resumeData.fullName}
          </h1>
          <div className="text-xs text-slate-600 font-medium flex flex-wrap items-center justify-center gap-3 pt-1">
            <span>{resumeData.email}</span>
            <span>•</span>
            <span>{resumeData.phone}</span>
            <span>•</span>
            <span>{resumeData.linkedin}</span>
            <span>•</span>
            <span>{resumeData.github}</span>
            <span>•</span>
            <span>{resumeData.portfolio}</span>
          </div>
        </div>

        {/* Education Section */}
        <div className="mt-5 space-y-2">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 pb-1 border-b border-slate-300">
            Education
          </h2>
          {resumeData.education.map((edu) => (
            <div key={edu.id} className="text-xs">
              <div className="flex items-center justify-between font-bold text-slate-900">
                <span>{edu.institution}</span>
                <span>
                  {edu.startYear} – {edu.endYear}
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-700 italic">
                <span>
                  {edu.degree} in {edu.fieldOfStudy}
                </span>
                <span className="font-semibold not-italic">CGPA: {edu.cgpa}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Experience Section */}
        <div className="mt-5 space-y-2">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 pb-1 border-b border-slate-300">
            Work Experience
          </h2>
          {resumeData.experience.map((exp) => (
            <div key={exp.id} className="text-xs space-y-1">
              <div className="flex items-center justify-between font-bold text-slate-900">
                <span>
                  {exp.role} — <span className="font-semibold text-slate-800">{exp.company}</span>
                </span>
                <span>
                  {exp.startDate} – {exp.endDate}
                </span>
              </div>
              <ul className="list-disc pl-4 space-y-1 text-slate-700 leading-relaxed">
                {exp.bulletPoints.map((bp, i) => (
                  <li key={i}>{bp}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Projects Section */}
        <div className="mt-5 space-y-2">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 pb-1 border-b border-slate-300">
            Technical Projects
          </h2>
          {resumeData.projects.map((proj) => (
            <div key={proj.id} className="text-xs space-y-1">
              <div className="flex items-center justify-between font-bold text-slate-900">
                <span>
                  {proj.title}{' '}
                  <span className="font-normal text-slate-600">| {proj.techStack}</span>
                </span>
                <span className="text-[11px] text-indigo-700 font-mono">
                  {proj.liveUrl || proj.githubUrl}
                </span>
              </div>
              <ul className="list-disc pl-4 space-y-1 text-slate-700 leading-relaxed">
                {proj.bulletPoints.map((bp, i) => (
                  <li key={i}>{bp}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Technical Skills Section */}
        <div className="mt-5 space-y-2">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 pb-1 border-b border-slate-300">
            Technical Skills
          </h2>
          <div className="text-xs space-y-1 text-slate-800">
            <div>
              <span className="font-bold">Languages: </span>
              <span>{resumeData.skills.languages}</span>
            </div>
            <div>
              <span className="font-bold">Frameworks & Libraries: </span>
              <span>{resumeData.skills.frameworks}</span>
            </div>
            <div>
              <span className="font-bold">Developer Tools & Cloud: </span>
              <span>{resumeData.skills.developerTools}</span>
            </div>
            <div>
              <span className="font-bold">Computer Science Fundamentals: </span>
              <span>{resumeData.skills.coreConcepts}</span>
            </div>
          </div>
        </div>

        {/* Achievements Section */}
        <div className="mt-5 space-y-2">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 pb-1 border-b border-slate-300">
            Honors & Achievements
          </h2>
          <ul className="list-disc pl-4 space-y-1 text-xs text-slate-700">
            {resumeData.achievements.map((ach, i) => (
              <li key={i}>{ach}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
