import React, { useState, useEffect } from 'react';
import {
  Code2,
  BrainCircuit,
  Map,
  Building2,
  TrendingUp,
  FileText,
  MessageSquare,
  Trophy,
  Users,
  Sun,
  Moon,
  Bell,
  Wifi,
  WifiOff,
  Flame,
  Zap,
  ExternalLink,
  Clock,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { JobDeadline } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab?: (tab: string) => void;
  onSelectTab?: (tab: string) => void;
  isDark?: boolean;
  isDarkMode?: boolean;
  toggleDarkMode?: () => void;
  onToggleDarkMode?: () => void;
  xp?: number;
  streakDays?: number;
  totalSolved?: number;
  deadlines: JobDeadline[];
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onSelectTab,
  isDark,
  isDarkMode,
  toggleDarkMode,
  onToggleDarkMode,
  xp = 4820,
  streakDays = 19,
  totalSolved = 148,
  deadlines,
}) => {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [showNotificationMenu, setShowNotificationMenu] = useState<boolean>(false);
  const [readNotifications, setReadNotifications] = useState<Record<string, boolean>>({});

  const handleSelectTab = (tabId: string) => {
    if (onSelectTab) {
      onSelectTab(tabId);
    } else if (setActiveTab) {
      setActiveTab(tabId);
    }
  };

  const handleToggleDark = () => {
    if (onToggleDarkMode) {
      onToggleDarkMode();
    } else if (toggleDarkMode) {
      toggleDarkMode();
    }
  };

  const isDarkModeActive = isDarkMode !== undefined ? isDarkMode : Boolean(isDark);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const urgentDeadlines = deadlines.filter((d) => d.daysLeft <= 14);
  const unreadCount = urgentDeadlines.filter((d) => !readNotifications[d.id]).length;

  const markAllRead = () => {
    const next: Record<string, boolean> = {};
    urgentDeadlines.forEach((d) => {
      next[d.id] = true;
    });
    setReadNotifications(next);
  };

  const navItems = [
    { id: 'arena', label: 'Coding Arena', icon: Code2, badge: 'Live Runner' },
    { id: 'interview', label: 'AI Mock Interview', icon: BrainCircuit, badge: 'AI' },
    { id: 'roadmap', label: 'Roadmap & Guides', icon: Map, badge: 'Beginner+' },
    { id: 'criteria', label: 'Hiring & Deadlines', icon: Building2, alertCount: unreadCount },
    { id: 'analytics', label: 'Progress Analytics', icon: TrendingUp },
    { id: 'resume', label: 'Resume Builder', icon: FileText, badge: 'ATS AI' },
    { id: 'forum', label: 'Peer Forum', icon: MessageSquare },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy, badge: 'Rank #5' },
    { id: 'projects', label: 'Collab & Portfolio', icon: Users, badge: 'Projects' },
  ];

  const isItemActive = (itemId: string) => {
    if (activeTab === itemId) return true;
    if (itemId === 'arena' && activeTab === 'coding') return true;
    if (itemId === 'criteria' && activeTab === 'companies') return true;
    if (itemId === 'projects' && activeTab === 'collab') return true;
    return false;
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/95 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95">
      {/* Top Banner for Offline or Urgent alert if applicable */}
      {!isOnline && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 text-amber-800 dark:text-amber-300 text-xs px-4 py-1.5 flex items-center justify-between font-medium">
          <div className="flex items-center gap-2">
            <WifiOff className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            <span>Offline Mode Active: All study sheets, solved problems, and cached materials are available offline.</span>
          </div>
          <span className="text-[11px] bg-amber-500/20 px-2 py-0.5 rounded font-mono">Cached Ready</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => handleSelectTab('arena')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 ring-2 ring-indigo-500/20">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 dark:from-indigo-400 dark:via-blue-400 dark:to-cyan-400 bg-clip-text text-transparent">
                  PlacementPrep
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  Student Pro
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium hidden sm:block">
                Master Coding, AI Interviews & Campus Placements
              </p>
            </div>
          </div>

          {/* Gamification Stats Bar */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 text-xs font-semibold text-slate-700 dark:text-slate-300">
            <div className="flex items-center gap-1.5 px-2 py-0.5 text-amber-600 dark:text-amber-400">
              <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
              <span>{streakDays}d Streak</span>
            </div>
            <div className="w-px h-3.5 bg-slate-300 dark:bg-slate-700" />
            <div className="flex items-center gap-1.5 px-2 py-0.5 text-indigo-600 dark:text-indigo-400">
              <Zap className="w-4 h-4 fill-indigo-500 text-indigo-500" />
              <span>{xp.toLocaleString()} XP</span>
            </div>
            <div className="w-px h-3.5 bg-slate-300 dark:bg-slate-700" />
            <div className="flex items-center gap-1.5 px-2 py-0.5 text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              <span>{totalSolved} Solved</span>
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Offline/Online status badge */}
            <div
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                isOnline
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
                  : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800'
              }`}
              title={isOnline ? 'Connected to AI & Live Services' : 'Running Offline with Cached Study Materials'}
            >
              {isOnline ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[11px]">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-500" />
                  <span className="text-[11px]">Offline Access</span>
                </>
              )}
            </div>

            {/* Notification bell for deadlines */}
            <div className="relative">
              <button
                id="notification-bell-button"
                onClick={() => setShowNotificationMenu(!showNotificationMenu)}
                className="relative p-2 rounded-lg text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                aria-label="Application Deadlines Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notification Popover Dropdown */}
              {showNotificationMenu && (
                <div
                  id="notifications-dropdown-menu"
                  className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-rose-500" />
                      <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100">
                        Upcoming Application Deadlines
                      </h4>
                    </div>
                    {unreadCount > 0 && (
                      <button
                        onClick={markAllRead}
                        className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
                      >
                        Mark all read
                      </button>
                    )}
                  </div>

                  <div className="mt-3 space-y-2.5 max-h-72 overflow-y-auto pr-1">
                    {urgentDeadlines.map((item) => (
                      <div
                        key={item.id}
                        className="p-2.5 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/70 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                        onClick={() => {
                          handleSelectTab('criteria');
                          setShowNotificationMenu(false);
                        }}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-slate-900 dark:text-slate-100">
                            {item.company} — {item.role}
                          </span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300">
                            {item.daysLeft}d left
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                          {item.ctcOffer} • {item.batch}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-xs text-slate-500">Need personalized alerts?</span>
                    <button
                      onClick={() => {
                        handleSelectTab('criteria');
                        setShowNotificationMenu(false);
                      }}
                      className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 hover:underline"
                    >
                      View All Deadlines <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Dark Mode Toggle */}
            <button
              id="dark-mode-toggle-button"
              onClick={handleToggleDark}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Toggle Dark Mode"
              title={isDarkModeActive ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {isDarkModeActive ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-700" />}
            </button>
          </div>
        </div>

        {/* Scrollable Navigation Bar Tabs */}
        <nav className="flex space-x-1 overflow-x-auto py-2 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = isItemActive(item.id);
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => handleSelectTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all select-none ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30 dark:bg-indigo-500'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-full uppercase tracking-wider font-bold ${
                      isActive
                        ? 'bg-indigo-700/80 text-white dark:bg-indigo-600'
                        : 'bg-slate-200/80 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {item.alertCount && item.alertCount > 0 ? (
                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                ) : null}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
