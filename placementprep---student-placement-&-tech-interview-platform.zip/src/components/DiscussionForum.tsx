import React, { useState } from 'react';
import {
  MessageSquare,
  ThumbsUp,
  Sparkles,
  Search,
  Plus,
  Send,
  CheckCircle2,
  HelpCircle,
  Clock,
  User,
  Bot,
  Tag,
} from 'lucide-react';
import { ForumPost } from '../types';

interface DiscussionForumProps {
  posts: ForumPost[];
  onAddPost: (post: ForumPost) => void;
  onUpvotePost: (postId: string) => void;
}

export const DiscussionForum: React.FC<DiscussionForumProps> = ({
  posts,
  onAddPost,
  onUpvotePost,
}) => {
  const [selectedPostId, setSelectedPostId] = useState<string>(posts[0]?.id || '');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Ask AI Doubt Solver state
  const [isSolvingWithAi, setIsSolvingWithAi] = useState<boolean>(false);
  const [newReplyText, setNewReplyText] = useState<string>('');

  // New Post Modal State
  const [showNewPostModal, setShowNewPostModal] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newCategory, setNewCategory] = useState<string>('Data Structures & Algorithms');
  const [newContent, setNewContent] = useState<string>('');
  const [newTags, setNewTags] = useState<string>('DSA, Arrays');

  const selectedPost = posts.find((p) => p.id === selectedPostId) || posts[0];

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const newPost: ForumPost = {
      id: 'post-' + Date.now(),
      title: newTitle,
      author: 'Alex Chen',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
      createdAt: 'Just now',
      category: newCategory,
      content: newContent,
      upvotes: 1,
      hasAiAnswer: false,
      replies: [],
      tags: newTags.split(',').map((t) => t.trim()),
    };

    onAddPost(newPost);
    setSelectedPostId(newPost.id);
    setShowNewPostModal(false);
    setNewTitle('');
    setNewContent('');
  };

  const handleAskAiSolver = async () => {
    if (!selectedPost || isSolvingWithAi) return;
    setIsSolvingWithAi(true);

    try {
      const response = await fetch('/api/gemini/doubt-solver', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          doubtTitle: selectedPost.title,
          doubtContent: selectedPost.content,
          category: selectedPost.category,
        }),
      });

      if (!response.ok) throw new Error('AI Solver error');
      const data = await response.json();

      const aiReply = {
        id: 'reply-ai-' + Date.now(),
        author: 'PlacementPrep AI Teaching Assistant',
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=ai-ta',
        createdAt: 'Just now',
        content: `${data.solutionExplanation}\n\nKey Takeaway: ${data.keyTakeaway}`,
        isAiAnswer: true,
        upvotes: 12,
      };

      selectedPost.replies.unshift(aiReply);
      selectedPost.hasAiAnswer = true;
    } catch (err) {
      console.error(err);
      const fallbackAiReply = {
        id: 'reply-ai-' + Date.now(),
        author: 'PlacementPrep AI Teaching Assistant',
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=ai-ta',
        createdAt: 'Just now',
        content: `Here is the comprehensive intuition for this problem:
1. Always formulate your base condition before diving into recursive states.
2. For overlapping subproblems, memoize the states using a 2D table dp[i][w].
3. For space optimization, observe that state i only depends on state i-1, allowing reduction to a single 1D array traversed backwards.`,
        isAiAnswer: true,
        upvotes: 8,
      };
      selectedPost.replies.unshift(fallbackAiReply);
      selectedPost.hasAiAnswer = true;
    } finally {
      setIsSolvingWithAi(false);
    }
  };

  const handleAddManualReply = () => {
    if (!newReplyText.trim() || !selectedPost) return;

    const reply = {
      id: 'reply-' + Date.now(),
      author: 'Alex Chen',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
      createdAt: 'Just now',
      content: newReplyText.trim(),
      isAiAnswer: false,
      upvotes: 0,
    };

    selectedPost.replies.push(reply);
    setNewReplyText('');
  };

  const filteredPosts = posts.filter((p) => {
    const matchCat = categoryFilter === 'All' || p.category === categoryFilter;
    const matchSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCat && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            <MessageSquare className="w-4 h-4" />
            <span>Peer Learning & Doubt Resolution</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight mt-1">
            Student Discussion Forum & AI Doubt Solver
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Resolve algorithmic bottlenecks, clarify OS/DBMS corner questions, and get feedback from peers and Gemini AI.
          </p>
        </div>

        <button
          onClick={() => setShowNewPostModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Ask a Doubt</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search doubts, DP, SQL, locks..."
            className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {[
            'All',
            'Data Structures & Algorithms',
            'System Design & Architecture',
            'Operating Systems & Concurrency',
            'Campus Placements & Off-Campus',
          ].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`text-xs px-3 py-1.5 rounded-xl font-semibold whitespace-nowrap border transition ${
                categoryFilter === cat
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {cat === 'Data Structures & Algorithms'
                ? 'DSA'
                : cat === 'System Design & Architecture'
                ? 'System Design'
                : cat === 'Operating Systems & Concurrency'
                ? 'OS Core'
                : cat === 'Campus Placements & Off-Campus'
                ? 'Placements'
                : 'All Topics'}
            </button>
          ))}
        </div>
      </div>

      {/* Main Forum Grid (List on Left 5 cols, Detail Thread on Right 7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Post List */}
        <div className="lg:col-span-5 space-y-3">
          {filteredPosts.map((post) => {
            const isSelected = post.id === selectedPost?.id;
            return (
              <div
                key={post.id}
                onClick={() => setSelectedPostId(post.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition space-y-2 ${
                  isSelected
                    ? 'bg-indigo-50/70 border-indigo-300 text-indigo-950 dark:bg-indigo-950/50 dark:border-indigo-800 dark:text-indigo-200'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">
                    {post.category}
                  </span>
                  <span className="text-slate-400">{post.createdAt}</span>
                </div>

                <h4 className="text-xs font-bold leading-snug line-clamp-2">{post.title}</h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                  {post.content}
                </p>

                <div className="flex items-center justify-between pt-1 text-[11px]">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-600 dark:text-slate-300">
                      {post.author}
                    </span>
                    {post.hasAiAnswer && (
                      <span className="px-1.5 py-0.5 rounded bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 text-[10px] font-bold flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5" /> AI Solved
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3 text-slate-500">
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-3 h-3" /> {post.upvotes}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-3 h-3" /> {post.replies.length}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Detailed Thread */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
          {selectedPost ? (
            <>
              {/* Question Detail */}
              <div className="space-y-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">
                    {selectedPost.category}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onUpvotePost(selectedPost.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span>{selectedPost.upvotes} Upvotes</span>
                    </button>

                    <button
                      id="ask-ai-doubt-solver-button"
                      onClick={handleAskAiSolver}
                      disabled={isSolvingWithAi}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition disabled:opacity-50 cursor-pointer shadow-xs"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{isSolvingWithAi ? 'AI Resolving...' : 'Ask AI TA to Solve'}</span>
                    </button>
                  </div>
                </div>

                <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
                  {selectedPost.title}
                </h2>

                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Asked by {selectedPost.author}
                  </span>
                  <span>•</span>
                  <span>{selectedPost.createdAt}</span>
                </div>

                <p className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed">
                  {selectedPost.content}
                </p>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {selectedPost.tags.map((t, i) => (
                    <span
                      key={i}
                      className="text-[10px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Replies List */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  Community & AI Solutions ({selectedPost.replies.length})
                </h3>

                {selectedPost.replies.length === 0 ? (
                  <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/40 text-center text-xs text-slate-500">
                    No solutions posted yet. Click "Ask AI TA to Solve" or post your reply below!
                  </div>
                ) : (
                  selectedPost.replies.map((reply) => (
                    <div
                      key={reply.id}
                      className={`p-4 rounded-2xl border space-y-2 ${
                        reply.isAiAnswer
                          ? 'bg-purple-50/50 border-purple-200 dark:bg-purple-950/30 dark:border-purple-800/70'
                          : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          {reply.isAiAnswer ? (
                            <div className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center text-[10px]">
                              <Bot className="w-3.5 h-3.5" />
                            </div>
                          ) : (
                            <div className="w-6 h-6 rounded-full bg-slate-600 text-white flex items-center justify-center text-[10px]">
                              <User className="w-3.5 h-3.5" />
                            </div>
                          )}
                          <span className="font-bold text-slate-900 dark:text-slate-100">
                            {reply.author}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400">{reply.createdAt}</span>
                      </div>

                      <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                        {reply.content}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Add Reply Input Box */}
              <div className="pt-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newReplyText}
                    onChange={(e) => setNewReplyText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddManualReply()}
                    placeholder="Contribute your solution or alternative approach..."
                    className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    onClick={handleAddManualReply}
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition"
                  >
                    Reply
                  </button>
                </div>
              </div>
            </>
          ) : null}
        </div>
      </div>

      {/* New Post Modal */}
      {showNewPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Ask a Doubt to Peers & AI
              </h3>
              <button onClick={() => setShowNewPostModal(false)} className="text-slate-400 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Question / Doubt Title
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Why does my Dijkstra implementation cause TLE on negative cycles?"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Topic Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                >
                  <option value="Data Structures & Algorithms">Data Structures & Algorithms</option>
                  <option value="System Design & Architecture">System Design & Architecture</option>
                  <option value="Operating Systems & Concurrency">Operating Systems & Concurrency</option>
                  <option value="Campus Placements & Off-Campus">Campus Placements & Off-Campus</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Detailed Explanation / Code snippet
                </label>
                <textarea
                  rows={4}
                  required
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="Explain what you tried, what output occurred, or paste relevant lines of code..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewPostModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-500"
                >
                  Post Doubt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
