import React, { useState } from 'react';
import {
  FolderGit2,
  Users,
  Sparkles,
  GitPullRequest,
  CheckCircle2,
  MessageSquare,
  ExternalLink,
  Code2,
  Send,
  Plus,
  Layers,
  Zap,
  Star,
  ShieldAlert,
} from 'lucide-react';
import { CollaborativeSpace } from '../types';

interface CollaborativeProjectsProps {
  spaces: CollaborativeSpace[];
  onAddReviewComment: (spaceId: string, author: string, comment: string) => void;
}

export const CollaborativeProjects: React.FC<CollaborativeProjectsProps> = ({
  spaces,
  onAddReviewComment,
}) => {
  const [activeTab, setActiveTab] = useState<'portfolio-advisor' | 'collab-spaces'>('portfolio-advisor');
  const [selectedSpaceId, setSelectedSpaceId] = useState<string>(spaces[0]?.id || '');
  const [newComment, setNewComment] = useState<string>('');

  // AI Portfolio Advisor state
  const [targetDomain, setTargetDomain] = useState<string>('Backend & Distributed Systems');
  const [isGeneratingProject, setIsGeneratingProject] = useState<boolean>(false);
  const [generatedProject, setGeneratedProject] = useState<any>(null);

  const selectedSpace = spaces.find((s) => s.id === selectedSpaceId) || spaces[0];

  const handleGeneratePortfolioIdea = async () => {
    setIsGeneratingProject(true);

    try {
      const response = await fetch('/api/gemini/portfolio-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          domain: targetDomain,
          experienceLevel: 'Entry-Level / Campus Placement',
          targetCompanies: ['Google', 'Uber', 'Atlassian', 'Amazon'],
        }),
      });

      if (!response.ok) throw new Error('Advisor failed');
      const data = await response.json();
      setGeneratedProject(data);
    } catch (err) {
      console.error(err);
      setGeneratedProject({
        projectTitle: 'Distributed Log-Structured Merge (LSM) Storage Engine',
        elevatorPitch:
          'A high-performance persistent key-value storage engine in Go implementing MemTables, Write-Ahead Logs (WAL), and multi-tier SSTable compaction similar to Apache Cassandra and RocksDB.',
        architectureOverview:
          'Incoming writes append to an append-only WAL for crash recovery and insert into an in-memory skip list (MemTable). When full, flushed asynchronously to disk as immutable SSTables with Bloom filters.',
        keyInterviewQuestions: [
          'How do Bloom filters eliminate unnecessary disk reads for non-existent keys?',
          'How do you prevent write stalls during background SSTable compaction?',
          'What are the trade-offs between B-Trees and LSM Trees for write-heavy workloads?',
        ],
        resumeBulletPoints: [
          'Engineered an LSM-Tree storage engine in Go handling 25,000 writes/second with sub-4ms P99 latency.',
          'Integrated Bloom filters with false-positive rates below 1%, reducing disk I/O seek operations by 65%.',
        ],
      });
    } finally {
      setIsGeneratingProject(false);
    }
  };

  const handleSendComment = () => {
    if (!newComment.trim() || !selectedSpace) return;
    onAddReviewComment(selectedSpace.id, 'Alex Chen', newComment.trim());
    setNewComment('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            <FolderGit2 className="w-4 h-4" />
            <span>Portfolio & Collaborative Engineering</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight mt-1">
            Portfolio Project Architect & Collaborative Peer Review Space
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Discover what projects actually get you hired at top tech firms, and conduct collaborative code reviews.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
          <button
            onClick={() => setActiveTab('portfolio-advisor')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'portfolio-advisor'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            What Project to Build (AI Advisor)
          </button>
          <button
            onClick={() => setActiveTab('collab-spaces')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'collab-spaces'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Peer Code Review Hub ({spaces.length})
          </button>
        </div>
      </div>

      {activeTab === 'portfolio-advisor' ? (
        /* PORTFOLIO PROJECT ADVISOR */
        <div className="space-y-6">
          {/* Advice Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-4 border border-indigo-900/50">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-400/30">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Recruiter Secret: Avoid Cliché Todo Apps & Clones</span>
              </div>
            </div>

            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              What Project Should You Build to Get Hired by Top Tech Companies?
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
              Recruiters at Google, Amazon, and top startups review thousands of Netflix and E-commerce clones daily. To stand out as an entry-level candidate, you need a project that demonstrates <strong>systems thinking, concurrency, distributed consensus, caching bottlenecks, or custom network protocols</strong>.
            </p>

            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <select
                value={targetDomain}
                onChange={(e) => setTargetDomain(e.target.value)}
                className="w-full sm:w-auto text-xs px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Backend & Distributed Systems">Backend & Distributed Systems</option>
                <option value="Frontend Architecture & Web Performance">Frontend Architecture & Web Performance</option>
                <option value="Fullstack SaaS with Real-Time Sockets">Fullstack SaaS with Real-Time Sockets</option>
                <option value="Low-Level Systems & Database Internals">Low-Level Systems & Database Internals</option>
              </select>

              <button
                id="generate-portfolio-project-button"
                onClick={handleGeneratePortfolioIdea}
                disabled={isGeneratingProject}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/30"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isGeneratingProject ? 'Architecting Blueprint...' : 'Generate High-Yield Project Spec'}</span>
              </button>
            </div>
          </div>

          {/* AI Project Blueprint Display */}
          {generatedProject && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5 animate-in fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                    Recommended SDE 1 Portfolio Blueprint
                  </span>
                  <h3 className="text-xl font-black text-slate-900 dark:text-slate-100 mt-1">
                    {generatedProject.projectTitle}
                  </h3>
                </div>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  Top 1% Resume Signal
                </span>
              </div>

              {/* Elevator Pitch */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs space-y-1">
                <span className="font-bold text-slate-900 dark:text-slate-100">Elevator Pitch for Interviewer:</span>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  "{generatedProject.elevatorPitch}"
                </p>
              </div>

              {/* Architecture & Tough Questions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/60 text-xs space-y-2">
                  <h4 className="font-bold text-indigo-900 dark:text-indigo-300 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-indigo-600" />
                    <span>Architecture Deep-Dive</span>
                  </h4>
                  <p className="text-indigo-950/90 dark:text-indigo-200 leading-relaxed">
                    {generatedProject.architectureOverview}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 text-xs space-y-2">
                  <h4 className="font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                    <Star className="w-4 h-4 text-amber-600" />
                    <span>Interview Questions You Will Be Asked</span>
                  </h4>
                  <ul className="space-y-1 text-amber-950/90 dark:text-amber-200">
                    {generatedProject.keyInterviewQuestions?.map((q: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="font-bold">•</span>
                        <span>{q}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Resume Bullet Points */}
              <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 text-xs space-y-2">
                <h4 className="font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Ready-to-Paste Resume Bullets (Google X-Y-Z Format)</span>
                </h4>
                <ul className="space-y-1.5 text-emerald-950/90 dark:text-emerald-200">
                  {generatedProject.resumeBulletPoints?.map((bp: string, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="font-bold text-emerald-600">✓</span>
                      <span>{bp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* COLLABORATIVE SPACES & PEER REVIEWS */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Spaces list (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            {spaces.map((space) => {
              const isSelected = space.id === selectedSpace?.id;
              return (
                <div
                  key={space.id}
                  onClick={() => setSelectedSpaceId(space.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition space-y-2 ${
                    isSelected
                      ? 'bg-indigo-50/70 border-indigo-300 text-indigo-950 dark:bg-indigo-950/50 dark:border-indigo-800 dark:text-indigo-200'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-mono font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {space.techStack}
                    </span>
                    <span className="text-slate-400">{space.membersCount} collaborators</span>
                  </div>

                  <h4 className="text-xs font-bold leading-snug">{space.projectTitle}</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                    {space.description}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Right: Code Review Workspace (8 cols) */}
          <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
            {selectedSpace && (
              <>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                      {selectedSpace.projectTitle}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">{selectedSpace.description}</p>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400">
                    <GitPullRequest className="w-4 h-4" />
                    <span>PR #4: Concurrency Patch</span>
                  </div>
                </div>

                {/* Code Snippet Under Review */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                    <span>Collaborative Codebase Inspection</span>
                    <span className="text-[10px] text-slate-400 font-mono">language: Go / Distributed</span>
                  </div>
                  <pre className="p-4 rounded-2xl bg-slate-950 text-emerald-400 font-mono text-xs overflow-x-auto leading-relaxed border border-slate-800">
                    {selectedSpace.activeCodeSnippet}
                  </pre>
                </div>

                {/* Review Comments Thread */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-indigo-500" />
                    <span>Peer Review Comments ({selectedSpace.reviewComments.length})</span>
                  </h4>

                  <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                    {selectedSpace.reviewComments.map((c) => (
                      <div
                        key={c.id}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900 dark:text-slate-100">
                            {c.author}
                          </span>
                          <span className="text-[10px] text-slate-400">{c.timestamp}</span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300">{c.comment}</p>
                      </div>
                    ))}
                  </div>

                  {/* Add review comment */}
                  <div className="flex gap-2 pt-2">
                    <input
                      type="text"
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendComment()}
                      placeholder="Leave inline review comment on locking, complexity, or edge cases..."
                      className="flex-1 text-xs px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button
                      onClick={handleSendComment}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition"
                    >
                      Post Comment
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
