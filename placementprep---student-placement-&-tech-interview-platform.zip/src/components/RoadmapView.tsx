import React, { useState } from 'react';
import {
  Map,
  CheckCircle2,
  Circle,
  Clock,
  ExternalLink,
  BookOpen,
  Sparkles,
  Download,
  Search,
  ChevronRight,
  Compass,
  FileCheck,
  Zap,
  HelpCircle,
} from 'lucide-react';
import { RoadmapPhase, StudySheet } from '../types';
import { saveOfflineData, OFFLINE_KEYS } from '../utils/offlineStorage';

interface RoadmapViewProps {
  phases: RoadmapPhase[];
  studySheets: StudySheet[];
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({ phases, studySheets }) => {
  const [activeTab, setActiveTab] = useState<'roadmap' | 'offline-sheets'>('roadmap');
  const [selectedSheetId, setSelectedSheetId] = useState<string>(studySheets[0].id);
  const [sheetSearch, setSheetSearch] = useState<string>('');
  const [savedOfflineAlert, setSavedOfflineAlert] = useState<string | null>(null);

  // Completed topics tracker
  const [completedTopicIds, setCompletedTopicIds] = useState<Record<string, boolean>>({
    'lang-syntax': true,
    'time-space-complexity': true,
  });

  const toggleTopic = (id: string) => {
    setCompletedTopicIds((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      saveOfflineData(OFFLINE_KEYS.PROGRESS, next);
      return next;
    });
  };

  const handleSaveAllOffline = () => {
    saveOfflineData(OFFLINE_KEYS.STUDY_SHEETS, studySheets);
    saveOfflineData(OFFLINE_KEYS.PROBLEMS, phases);
    setSavedOfflineAlert('All study sheets and roadmap curricula saved to local offline cache!');
    setTimeout(() => setSavedOfflineAlert(null), 3000);
  };

  const selectedSheet = studySheets.find((s) => s.id === selectedSheetId) || studySheets[0];

  const filteredSheets = studySheets.filter(
    (s) =>
      s.title.toLowerCase().includes(sheetSearch.toLowerCase()) ||
      s.category.toLowerCase().includes(sheetSearch.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            <Compass className="w-4 h-4" />
            <span>Placement Preparation Blueprint</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight mt-1">
            Study Roadmap & Curated Company Resources
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Designed for beginner to job-ready entry-level engineers targeting Google, Amazon, Microsoft & top startups.
          </p>
        </div>

        {/* Action Tabs & Offline Download */}
        <div className="flex items-center gap-2">
          <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setActiveTab('roadmap')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeTab === 'roadmap'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Beginner Roadmap
            </button>
            <button
              onClick={() => setActiveTab('offline-sheets')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeTab === 'offline-sheets'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Offline Study Notes (OS/DBMS/CN)
            </button>
          </div>

          <button
            onClick={handleSaveAllOffline}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white dark:bg-slate-700 dark:hover:bg-slate-600 transition"
            title="Download notes to browser storage for offline access"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Save Offline</span>
          </button>
        </div>
      </div>

      {savedOfflineAlert && (
        <div className="mb-4 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{savedOfflineAlert}</span>
        </div>
      )}

      {activeTab === 'roadmap' ? (
        <div className="space-y-6">
          {/* "How to Start Journey for a Beginner" Guide Banner */}
          <div className="bg-gradient-to-r from-indigo-900 via-blue-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
            <div className="max-w-3xl relative z-10 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Beginner Strategy: Zero to First SDE Placement</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                How to Start Your Journey as an Entry-Level Developer
              </h2>
              <p className="text-xs sm:text-sm text-indigo-100/90 leading-relaxed">
                Start by picking <strong>ONE primary language</strong> (C++ or Java for deep OOPs/memory, or Python for fast syntax). Do not bounce between languages. Spend the first 3 weeks building absolute fluency with syntax, arrays, hash maps, and recursion before touching dynamic programming. Once foundations are set, practice topic-by-topic using classic patterns rather than random problem solving.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10">
                  <div className="text-xs font-bold text-indigo-300">Phase 0 (Weeks 1-3)</div>
                  <div className="text-xs text-white/90 mt-0.5">Language syntax, memory layout & Big-O complexity</div>
                </div>
                <div className="p-3 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10">
                  <div className="text-xs font-bold text-indigo-300">Phase 1 (Weeks 4-8)</div>
                  <div className="text-xs text-white/90 mt-0.5">Linear structures: Arrays, Two Pointers, Sliding Window</div>
                </div>
                <div className="p-3 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10">
                  <div className="text-xs font-bold text-indigo-300">Phase 2-3 (Weeks 9-18)</div>
                  <div className="text-xs text-white/90 mt-0.5">Trees, Graphs, DP + Core CS (OS, DBMS, CN) + Mocks</div>
                </div>
              </div>
            </div>
          </div>

          {/* Structured Phase Stages */}
          <div className="space-y-6">
            {phases.map((phase) => (
              <div
                key={phase.phaseNumber}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">
                        Phase {phase.phaseNumber} • {phase.weeks}
                      </span>
                      <span className="text-xs font-bold text-slate-500 uppercase">{phase.level}</span>
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mt-1">
                      {phase.title}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 max-w-md">{phase.summary}</p>
                </div>

                {/* Topics in this phase */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {phase.topics.map((topic) => {
                    const isDone = Boolean(completedTopicIds[topic.id]);
                    return (
                      <div
                        key={topic.id}
                        className={`p-4 rounded-2xl border transition ${
                          isDone
                            ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
                            : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/80'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-2.5">
                            <button
                              onClick={() => toggleTopic(topic.id)}
                              className="mt-0.5 text-slate-400 hover:text-indigo-600 transition cursor-pointer"
                              title={isDone ? 'Mark Incomplete' : 'Mark Completed'}
                            >
                              {isDone ? (
                                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 fill-emerald-100 dark:fill-emerald-950" />
                              ) : (
                                <Circle className="w-5 h-5" />
                              )}
                            </button>
                            <div>
                              <h4
                                className={`text-xs font-bold ${
                                  isDone
                                    ? 'line-through text-slate-400 dark:text-slate-500'
                                    : 'text-slate-900 dark:text-slate-100'
                                }`}
                              >
                                {topic.title}
                              </h4>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                                {topic.description}
                              </p>
                            </div>
                          </div>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 shrink-0">
                            ~{topic.estimatedHours} hrs
                          </span>
                        </div>

                        {/* Problems & Links */}
                        <div className="mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-700/60 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-slate-400 font-medium">Practice:</span>
                            {topic.problemsToSolve.map((pName, idx) => (
                              <span
                                key={idx}
                                className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-300"
                              >
                                {pName}
                              </span>
                            ))}
                          </div>

                          {topic.resourceLinks.map((res, i) => (
                            <a
                              key={i}
                              href={res.url}
                              target="_blank"
                              rel="noreferrer"
                              className="text-indigo-600 dark:text-indigo-400 hover:underline font-semibold flex items-center gap-1"
                            >
                              <span>{res.label}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Offline Study Notes (OS, DBMS, CN, System Design) */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Study Notes Selector (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-sm">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={sheetSearch}
                  onChange={(e) => setSheetSearch(e.target.value)}
                  placeholder="Search CS notes, OS, SQL, Networks..."
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="space-y-2">
              {filteredSheets.map((sheet) => {
                const isSelected = sheet.id === selectedSheet.id;
                return (
                  <div
                    key={sheet.id}
                    onClick={() => setSelectedSheetId(sheet.id)}
                    className={`p-4 rounded-2xl border cursor-pointer transition ${
                      isSelected
                        ? 'bg-indigo-50 border-indigo-300 text-indigo-950 dark:bg-indigo-950/60 dark:border-indigo-800 dark:text-indigo-200'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] font-bold text-indigo-600 dark:text-indigo-400 mb-1">
                      <span>{sheet.category}</span>
                      <span className="text-slate-400 font-normal">{sheet.readTime}</span>
                    </div>
                    <h4 className="text-xs font-bold leading-snug">{sheet.title}</h4>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Study Sheet Reader (8 cols) */}
          <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                  {selectedSheet.category}
                </span>
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 mt-1">
                  {selectedSheet.title}
                </h2>
              </div>
              <span className="text-xs font-mono px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                {selectedSheet.readTime}
              </span>
            </div>

            {/* Key Takeaways Card */}
            <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/70 space-y-2">
              <h4 className="text-xs font-bold text-indigo-900 dark:text-indigo-300 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-indigo-600" />
                <span>High-Yield Interview Takeaways</span>
              </h4>
              <ul className="space-y-1 text-xs text-indigo-950/90 dark:text-indigo-200">
                {selectedSheet.keyTakeaways.map((takeaway, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-indigo-500 font-bold">•</span>
                    <span>{takeaway}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Content Markdown/Text */}
            <div className="prose dark:prose-invert max-w-none text-xs leading-relaxed text-slate-700 dark:text-slate-300 whitespace-pre-line">
              {selectedSheet.contentMarkdown}
            </div>

            {/* Top Interview Questions */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-indigo-500" />
                <span>Frequently Asked Interview Questions</span>
              </h3>

              <div className="space-y-3">
                {selectedSheet.commonInterviewQuestions.map((q, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-1.5"
                  >
                    <div className="font-bold text-xs text-slate-900 dark:text-slate-100">
                      Q: {q.question}
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      <span className="font-semibold text-indigo-600 dark:text-indigo-400">Model Answer: </span>
                      {q.answerSummary}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
