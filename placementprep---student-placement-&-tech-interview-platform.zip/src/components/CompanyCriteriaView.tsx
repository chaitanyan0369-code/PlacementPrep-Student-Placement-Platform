import React, { useState } from 'react';
import {
  Building2,
  Calendar,
  Clock,
  ExternalLink,
  Search,
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  DollarSign,
  GraduationCap,
  Sparkles,
  Filter,
  Plus,
  Bell,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { CompanyHiringCriteria, JobDeadline } from '../types';

interface CompanyCriteriaViewProps {
  companies: CompanyHiringCriteria[];
  deadlines: JobDeadline[];
  onToggleBookmark: (deadlineId: string) => void;
  onAddCustomDeadline: (deadline: JobDeadline) => void;
}

export const CompanyCriteriaView: React.FC<CompanyCriteriaViewProps> = ({
  companies,
  deadlines,
  onToggleBookmark,
  onAddCustomDeadline,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'criteria' | 'deadlines'>('deadlines');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('All');
  const [expandedCompanyId, setExpandedCompanyId] = useState<string | null>(companies[0].id);

  // New Custom Deadline Form modal
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newCompany, setNewCompany] = useState<string>('');
  const [newRole, setNewRole] = useState<string>('');
  const [newDate, setNewDate] = useState<string>('');
  const [newType, setNewType] = useState<'Internship' | 'Full-Time'>('Internship');
  const [newCtc, setNewCtc] = useState<string>('');
  const [newEligibility, setNewEligibility] = useState<string>('');
  const [newApplyLink, setNewApplyLink] = useState<string>('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompany || !newRole || !newDate) return;

    const daysCalc = Math.max(
      1,
      Math.ceil((new Date(newDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    );

    const deadlineObj: JobDeadline = {
      id: 'custom-' + Date.now(),
      company: newCompany,
      role: newRole,
      type: newType,
      location: 'On-Campus / Hybrid',
      deadlineDate: newDate,
      daysLeft: daysCalc,
      ctcOffer: newCtc || 'Competitive CTC',
      eligibility: newEligibility || 'All CS / IT Branches',
      applyLink: newApplyLink || '#',
      batch: '2026/2027 Batch',
      tags: ['On-Campus', 'Custom'],
      isBookmarked: true,
    };

    onAddCustomDeadline(deadlineObj);
    setShowAddModal(false);
    setNewCompany('');
    setNewRole('');
    setNewDate('');
  };

  const filteredDeadlines = deadlines.filter((d) => {
    const matchSearch =
      d.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.batch.toLowerCase().includes(searchQuery.toLowerCase());
    const matchType = filterType === 'All' || d.type === filterType;
    return matchSearch && matchType;
  });

  const filteredCompanies = companies.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.preferredTechStack.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            <Building2 className="w-4 h-4" />
            <span>Campus Placements & Off-Campus Drives</span>
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight mt-1">
            Top Tech Hiring Criteria & Deadline Tracker
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Round breakdowns, cut-offs, compensation benchmarks, and countdown deadline alerts.
          </p>
        </div>

        {/* Sub Navigation & Add Deadline Button */}
        <div className="flex items-center gap-3">
          <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setActiveSubTab('deadlines')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeSubTab === 'deadlines'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Live Deadlines ({deadlines.length})
            </button>
            <button
              onClick={() => setActiveSubTab('criteria')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeSubTab === 'criteria'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Hiring Criteria ({companies.length})
            </button>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Track Deadline</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              activeSubTab === 'deadlines'
                ? 'Search company, role, batch...'
                : 'Search company, tech stack, criteria...'
            }
            className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {activeSubTab === 'deadlines' && (
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs text-slate-500 font-medium">Filter:</span>
            {['All', 'Internship', 'Full-Time'].map((t) => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`text-xs px-3 py-1 rounded-lg font-semibold border transition ${
                  filterType === t
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* DEADLINES TAB */}
      {activeSubTab === 'deadlines' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDeadlines.map((item) => {
            const isUrgent = item.daysLeft <= 14;
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-md transition"
              >
                <div className="space-y-3">
                  {/* Top line with urgency and bookmark */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                        isUrgent
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 animate-pulse'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300'
                      }`}
                    >
                      <Clock className="w-3 h-3" />
                      <span>{item.daysLeft} days left</span>
                    </span>

                    <button
                      onClick={() => onToggleBookmark(item.id)}
                      className="text-slate-400 hover:text-indigo-600 transition p-1"
                      title={item.isBookmarked ? 'Bookmarked' : 'Bookmark this deadline'}
                    >
                      {item.isBookmarked ? (
                        <BookmarkCheck className="w-5 h-5 text-indigo-600 fill-indigo-100 dark:fill-indigo-950" />
                      ) : (
                        <Bookmark className="w-5 h-5" />
                      )}
                    </button>
                  </div>

                  {/* Company & Role */}
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {item.type} • {item.batch}
                    </span>
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100 mt-1.5">
                      {item.company}
                    </h3>
                    <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400">{item.role}</div>
                  </div>

                  {/* Compensation & Criteria */}
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs space-y-1">
                    <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                      <span className="text-slate-400">Offer / Stipend:</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{item.ctcOffer}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                      <span className="text-slate-400">Eligibility:</span>
                      <span className="font-medium truncate max-w-[160px]">{item.eligibility}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                      <span className="text-slate-400">Last Date:</span>
                      <span className="font-mono font-bold">{item.deadlineDate}</span>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5">
                    {item.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Apply Link */}
                <a
                  href={item.applyLink}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white text-xs font-bold flex items-center justify-center gap-1.5 transition"
                >
                  <span>Apply on Official Portal</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            );
          })}
        </div>
      )}

      {/* HIRING CRITERIA TAB */}
      {activeSubTab === 'criteria' && (
        <div className="space-y-4">
          {filteredCompanies.map((comp) => {
            const isExpanded = expandedCompanyId === comp.id;
            return (
              <div
                key={comp.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4 transition"
              >
                {/* Header Summary Row */}
                <div
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer"
                  onClick={() => setExpandedCompanyId(isExpanded ? null : comp.id)}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center p-2 border border-slate-200 dark:border-slate-700">
                      <img
                        src={comp.logo}
                        alt={comp.name}
                        className="w-8 h-8 object-contain"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">{comp.name}</h3>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                          {comp.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">
                        Min CGPA: <strong>{comp.minCgpa}+</strong> • Average Package: <strong>{comp.avgCtc}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`text-xs px-2.5 py-1 rounded-xl font-bold ${
                        comp.dsaDifficulty === 'Hard'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      DSA: {comp.dsaDifficulty}
                    </span>
                    <button className="text-slate-400 hover:text-slate-600">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4 animate-in fade-in">
                    {/* Rounds Breakdown */}
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">
                        Interview Rounds Architecture
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {comp.rounds.map((r, i) => (
                          <div
                            key={i}
                            className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs space-y-1"
                          >
                            <div className="font-bold text-indigo-600 dark:text-indigo-400">
                              Round {i + 1}: {r.roundName}
                            </div>
                            <div className="text-slate-800 dark:text-slate-200 font-medium">{r.focus}</div>
                            <div className="text-[11px] text-slate-500 italic pt-1">
                              💡 Strategy: {r.prepStrategy}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Insider Tips & Preferred Stack */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/70 text-xs space-y-1.5">
                        <h5 className="font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Insider Placement Tips</span>
                        </h5>
                        <p className="text-amber-900/90 dark:text-amber-200 leading-relaxed">
                          {comp.insiderTips}
                        </p>
                      </div>

                      <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/70 text-xs space-y-2">
                        <h5 className="font-bold text-indigo-900 dark:text-indigo-300">
                          Target Core Topics to Master
                        </h5>
                        <div className="flex flex-wrap gap-1.5">
                          {comp.targetTopics.map((topic, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 text-indigo-800 dark:text-indigo-200 border border-indigo-200 dark:border-indigo-800 text-[11px] font-semibold"
                            >
                              {topic}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add Custom Deadline Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Track New College or Off-Campus Deadline
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Company Name
                </label>
                <input
                  type="text"
                  required
                  value={newCompany}
                  onChange={(e) => setNewCompany(e.target.value)}
                  placeholder="e.g. Cisco, Oracle, Qualcomm..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Role Title
                  </label>
                  <input
                    type="text"
                    required
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value)}
                    placeholder="e.g. Graduate Software Engineer"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Type
                  </label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  >
                    <option value="Internship">Internship</option>
                    <option value="Full-Time">Full-Time</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Deadline Date
                  </label>
                  <input
                    type="date"
                    required
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Package (CTC / Stipend)
                  </label>
                  <input
                    type="text"
                    value={newCtc}
                    onChange={(e) => setNewCtc(e.target.value)}
                    placeholder="e.g. 24 LPA or ₹80,000/mo"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Application Link or Portal
                </label>
                <input
                  type="text"
                  value={newApplyLink}
                  onChange={(e) => setNewApplyLink(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-500"
                >
                  Save Deadline Alert
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
